'use strict';
const fs = require('fs'), path = require('path');
const { DIR } = require('./config');

const FILE = path.join(DIR, 'knowledge.json');
const TEXT_EXT = new Set(['.md', '.txt', '.js', '.ts', '.tsx', '.jsx', '.py', '.json', '.html', '.css', '.c', '.h', '.cpp', '.cs',
  '.java', '.go', '.rs', '.sh', '.bat', '.ps1', '.yml', '.yaml', '.toml', '.rb', '.php', '.sql', '.csv', '.log', '.ini', '.cfg', '.xml', '.rst']);
const IGN = new Set(['node_modules', '.git', '__pycache__', '.venv', 'venv', 'dist', 'build', 'target']);
let db = null;

function load() {
  if (db) return db;
  try { db = JSON.parse(fs.readFileSync(FILE, 'utf8')); } catch { db = { docs: [] }; }
  return db;
}
function save() { fs.mkdirSync(DIR, { recursive: true }); fs.writeFileSync(FILE, JSON.stringify(db)); }

function chunk(text, size = 1200) {
  const out = []; let cur = '';
  for (const p of text.split(/\n{2,}/)) {
    if (cur && (cur + p).length > size) { out.push(cur.trim()); cur = ''; }
    cur += p + '\n\n';
    while (cur.length > size * 2) { out.push(cur.slice(0, size)); cur = cur.slice(size); }
  }
  if (cur.trim()) out.push(cur.trim());
  return out;
}

function addText(text, source) {
  const d = load();
  d.docs = d.docs.filter((x) => x.source !== source);
  d.docs.push({ source, added: new Date().toISOString(), chunks: chunk(text) });
  save();
}

function* files(p) {
  const st = fs.statSync(p);
  if (st.isFile()) { yield p; return; }
  for (const e of fs.readdirSync(p, { withFileTypes: true })) {
    if (IGN.has(e.name)) continue;
    const f = path.join(p, e.name);
    if (e.isDirectory()) yield* files(f); else yield f;
  }
}

function addPath(p) {
  let n = 0;
  for (const f of files(p)) {
    if (!TEXT_EXT.has(path.extname(f).toLowerCase())) continue;
    if (fs.statSync(f).size > 500000) continue;
    addText(fs.readFileSync(f, 'utf8'), f); n++;
  }
  return n;
}

const tok = (s) => s.toLowerCase().match(/[a-z0-9_]{3,}/g) || [];

function search(q, k = 4) {
  const d = load(), qt = [...new Set(tok(q))];
  if (!qt.length) return [];
  const all = [];
  for (const doc of d.docs) for (const c of doc.chunks) all.push({ source: doc.source, text: c, t: tok(c) });
  const N = all.length;
  if (!N) return [];
  for (const x of all) { x.tf = {}; for (const t of x.t) x.tf[t] = (x.tf[t] || 0) + 1; }
  const idf = {};
  for (const t of qt) idf[t] = Math.log(1 + N / (1 + all.filter((x) => x.tf[t]).length));
  return all
    .map((x) => ({ source: x.source, text: x.text, score: qt.reduce((s, t) => s + (x.tf[t] ? Math.log(1 + x.tf[t]) * idf[t] : 0), 0) }))
    .filter((x) => x.score > 0).sort((a, b) => b.score - a.score).slice(0, k);
}

const list = () => load().docs.map((d, i) => ({ id: i + 1, source: d.source, chunks: d.chunks.length, added: d.added }));
function remove(key) {
  const d = load(), before = d.docs.length;
  const n = Number(key);
  d.docs = d.docs.filter((x, i) => (Number.isInteger(n) && n > 0 ? i + 1 !== n : x.source !== key));
  save();
  return before - d.docs.length;
}
function clear() { load().docs = []; save(); }

module.exports = { addText, addPath, search, list, remove, clear };
