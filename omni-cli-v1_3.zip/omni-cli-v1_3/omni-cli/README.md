# Omni CLI

One terminal app for **Ollama, Claude, Gemini, OpenAI and xAI (Grok)** on Windows and Linux (macOS works too).
Zero dependencies — just Node.js 18+.

## Install
**Linux:** `sh install.sh`  **Windows:** double-click `install.bat` (use Windows Terminal for the best look)
Or run without installing: `node bin/omni.js`
Single binary (optional): `bun build --compile bin/omni.js --outfile omni`

## First run
```
omni
/provider claude            # switch provider (logo changes, Claude Code style)
/key claude sk-ant-...      # saved to ~/.omni/config.json (or use env vars)
/model sonnet               # aliases: sonnet, opus, haiku, fable — or any part of a model name (/model qwen)
/provider claude:opus       # switch provider and model in one go
```
Env vars: `ANTHROPIC_API_KEY`, `GEMINI_API_KEY`, `OPENAI_API_KEY`, `XAI_API_KEY`, `OLLAMA_HOST`.
Ollama needs no key — just `ollama serve`.

## Features
- **463 skills, all active** — every message is scored against all skills and the best few (default 4, `/skills max 6`) are injected automatically, so a small local model keeps its context window. You see `⚡ skills: debug, expert-python` before each answer. Pin skills you always want with `/skill code-review`; turn routing off with `/skills auto off`.
  Categories: coding, **workflow** (git, testing, perf, security, APIs, DB, DevOps, debugging… 100+ developer skills), AI apps (RAG, agents, evals, MCP, local LLMs), writing, business, thinking, life, creative, data, plus 200 `expert-*` technology personas (languages, frameworks, tools, clouds).
- **New in 1.3**
  - `/each <prompt>` — ask **every installed Ollama model** the same thing, then get a speed ranking. `/bench` — tokens/s of the current model.
  - `/refactor <file> <change>` — AI edits a file, shows a coloured diff, applies only if you confirm (undo with git).
  - `/lint`, `/build` — auto-detected, streamed, with an offer to have the agent fix failures (like `/test`).
  - `/standup` (from your recent commits), `/readme` (agent writes/improves README.md), `/log [n]`, `/tree [depth]`.
  - Project scans without any AI: `/todos`, `/loc`, `/secrets` (leaked keys/tokens), `/deps`, `/ports [port]`.
  - Pocket utilities: `/uuid`, `/hash`, `/b64`, `/urlenc`, `/jwt`, `/ts`, `/regex /pat/flags text`, `/calc`.
  - `/serve [port]` — static HTTP server for the current folder.
  - `/macro add <name> <prompt with {{args}}>` — **make your own slash commands**; `/macro list`, `/macro rm <name>`. Example: `/macro add tldr Summarize in 3 bullets: {{args}}` then `/tldr <text>`.
- **Developer commands**
  - `/review [staged|branch main|file]` — AI review of your git changes (severity-ranked, with fixes)
  - `/commit [-a]` — Conventional Commit message from the staged diff, matching your repo's style; confirm / edit / cancel
  - `/test [cmd]` — auto-detects npm/pytest/cargo/go/maven/gradle/make, runs it, and offers to have the agent fix failures
  - `/diff`, `/status`, `/find <regex>`, `/explain <file>`, `/todo`
  - `/plan` — plan mode: the model can read and search but every write/command is blocked; ask for a plan, review it, then `/plan off`
  - `/info -l` — details of the last response: time, tokens in/out, tokens/s, context usage, skills used, agent tool calls (`/info` = whole session; also `omni info -l` from your shell)
  - `/models [filter|all]` — numbered model list with the current one marked (Ollama shows size, parameters, quantization)
  - `/pr`, `/changelog`, `/tests <file>`, `/fix <file>`, `/docs <file>`, `/optimize <file>`, `/security <file>`, `/edit` (compose in $EDITOR), `/history`
  - `/copy code` — copy the last code block; `/ctx 16384` — Ollama context window
- **Agent mode** — `/agent on`: the model plans and uses 35 tools (read/read_many/write/edit files, symbols outline, tree, glob, grep, shell, run_tests, **lint, build**, git, web search/fetch, HTTP, file ops, project summary, **deps, loc, scan_todos, scan_secrets, json_query, diff_files, hash, encode (base64/url/hex/uuid/JWT/timestamps), regex_test, ports**, todo, remember/recall, calculator, sysinfo, ask_user). Risky actions ask for approval (`y / n / a`); `/auto` or `-y` skips prompts.
- **Readable output** — fenced code blocks, headings, **bold** and `inline code` are styled as they stream; copy/paste of code is unaffected.
- **Git-aware UI** — branch and dirty-file count in the prompt rule and welcome panel, detected project stack (Node, Python, Rust, Go…).
- **Works with every installed Ollama model** — each model is probed (`/api/show`) so Omni sends `think` only to models that support it, caps the context window at the model's real maximum, hides embedding-only models from `/model` and `/models`, falls back to an installed model if the default isn't pulled, and shows context size plus `think` / `tools` / `vision` tags in `/models`.
- **Pixel-art provider mascots** — a proper Ollama llama (and per-provider colours).
- **Thinking effect** — animated spinner with shimmering verbs, timer and token counter; the model's reasoning streams live in dim italics (`/thinking` to hide).
- **Effort** — `/effort low|medium|high|max` maps to Claude/Gemini thinking budgets, OpenAI/xAI reasoning effort, Ollama think mode.
- **Knowledge base** — `/kb add <file|folder|text>`; relevant chunks are injected automatically. The agent can `remember` / `recall` too.
- **Project memory** — put an `OMNI.md` in a folder (or run `/init` and let the agent write it).
- **Sessions** — `/save`, `/load`, `/export`, `/compact`, `/undo`, `/retry`, `/copy`, `/usage`, `/doctor`.
- **Shortcuts** — `!cmd` runs a shell command, `@file` attaches a file, trailing `\` continues a line, Tab completes, Ctrl+C interrupts.

## One-shot / scripting
```
omni -p "explain this error" -P openai -m gpt-5 -e high
omni -p "review my changes" -P claude:opus --plan
cat app.log | omni -p "find the root cause" -P claude
omni -p "add a --verbose flag to cli.js" -a -y -P ollama -m qwen3
```

## Notes
- Agent tool calls use a text protocol (`<tool>{json}</tool>`), so every provider — including small local models — works the same way.
- Model names change often; use `/models` or `/model <name>` if a default isn't available on your account.
- Config and history live in `~/.omni` (set `OMNI_HOME` to move it).
