'use strict';
// A skill = a named expert mode. Activating one adds its instructions to the system prompt.
// Format: 'name: instruction'. Some are hand-written task modes; the "expert-*" ones are generated from a technology list.

const RAW = {
  coding: [
    'code-review: Review the code like a senior engineer: list bugs, security and performance risks and readability issues by severity, each with a concrete fix.',
    'debug: Debug systematically: restate symptoms, rank hypotheses by likelihood, say how to test each, then give the most probable fix.',
    'refactor: Refactor for clarity and maintainability without changing behavior; explain each change briefly and show the final code.',
    'write-tests: Write thorough unit tests covering happy paths, edge cases and failures with the project\'s existing test framework.',
    'tdd: Work test-first: write failing tests, then the minimal code to pass, then refactor.',
    'explain-code: Explain the code step by step at the reader\'s level, then summarize its purpose and gotchas.',
    'optimize: Find bottlenecks, propose optimizations ranked by impact with complexity analysis and a way to benchmark each.',
    'security-audit: Audit for vulnerabilities (OWASP Top 10, secrets, injection, authz, unsafe deserialization); give severity, exploit scenario and fix.',
    'commit-message: Write a Conventional Commits message (type(scope): summary plus body) from the diff or description.',
    'pr-description: Write a pull request description: summary, motivation, changes, testing, risks and rollout notes.',
    'changelog: Turn commits or notes into a Keep-a-Changelog entry grouped by Added/Changed/Fixed/Removed.',
    'readme-writer: Write a clear README: what it is, install, quick start, usage examples, configuration, contributing, license.',
    'api-design: Design a clean REST/GraphQL API: resources, endpoints, schemas, status codes, pagination, errors, versioning and auth.',
    'db-schema: Design a normalized database schema with keys, indexes, constraints and migration SQL; note trade-offs.',
    'sql-optimize: Optimize the SQL: reason about the query plan, suggest indexes and rewrites, and explain expected gains.',
    'regex-builder: Build and explain a regular expression for the pattern, with test strings that match and do not match.',
    'shell-oneliner: Give a correct shell one-liner (Bash and PowerShell variants) with a short explanation of each part.',
    'dockerize: Create an optimized, secure multi-stage Dockerfile and docker-compose.yml for the project.',
    'ci-pipeline: Write a CI/CD pipeline (GitHub Actions by default) with caching, lint, tests, build and deploy stages.',
    'k8s-manifest: Write production-ready Kubernetes manifests with probes, resource limits, config and security context.',
    'code-migrate: Migrate code between languages, frameworks or versions preserving behavior; list incompatibilities and manual steps.',
    'doc-comments: Add accurate doc comments/docstrings in the language\'s standard style without altering code.',
    'type-annotate: Add precise static types/annotations and fix the type errors that surface.',
    'error-handling: Harden error handling: identify failure modes, add validation, retries/timeouts and meaningful messages.',
    'logging-setup: Add structured logging with levels and context, no sensitive data; suggest metrics worth tracking.',
    'architecture-review: Review the architecture: boundaries, coupling, scalability, reliability, operability; prioritized recommendations.',
    'system-design: Design the system: requirements, capacity estimates, components, data flow, trade-offs, failure modes, text diagram.',
    'threat-model: Build a STRIDE threat model: assets, trust boundaries, threats and mitigations ranked by risk.',
    'log-analyzer: Analyze the logs: find the root cause, build a timeline, separate signal from noise, suggest next diagnostics.',
    'bug-report: Turn the description into a precise bug report: title, environment, steps, expected vs actual, logs, suspected cause.',
    'algorithm-coach: Teach the algorithm: pattern, brute force to optimal, complexity, edge cases, then clean code.',
    'legacy-modernize: Modernize legacy code incrementally with characterization tests, safe steps and a rollback plan.',
    'cli-designer: Design a CLI: commands, flags, help text, exit codes, config and examples following common conventions.',
  ],
  writing: [
    'summarize: Summarize the text faithfully in a short paragraph plus key bullet points; keep numbers and names accurate.',
    'tldr: Give a one to two sentence TL;DR of the content.',
    'eli5: Explain the topic simply, with an everyday analogy, as if to a curious ten-year-old.',
    'proofread: Fix spelling, grammar and punctuation only; show corrections and keep the author\'s voice.',
    'editor: Edit for clarity, flow and concision; show the improved text and a short list of the main changes.',
    'rewrite-formal: Rewrite the text in a polished, professional register.',
    'rewrite-casual: Rewrite the text in a friendly, conversational tone.',
    'tone-adjust: Rewrite the text in the requested tone while keeping the meaning intact.',
    'email-writer: Write a clear, well-structured email with subject line, right tone and a specific call to action.',
    'cover-letter: Write a tailored cover letter that connects the candidate\'s experience to the role with concrete achievements.',
    'resume-review: Review the resume for impact, clarity and ATS fit; rewrite weak bullets with metrics.',
    'blog-outline: Produce a blog post outline: hook, headings, key points per section, and a conclusion with a call to action.',
    'copywriter: Write persuasive, benefit-led copy with a strong hook and a clear call to action.',
    'ad-copy: Write several short ad variations (headline plus body) for different angles and platforms.',
    'tweet-thread: Write an engaging thread: strong first post, one idea per post, concise, with a closing call to action.',
    'linkedin-post: Write a LinkedIn post with a scroll-stopping first line, short paragraphs and a takeaway.',
    'youtube-script: Write a video script: hook, intro, segmented body with visual cues, and outro with call to action.',
    'product-description: Write a compelling product description: key benefits first, then features, specs and a closing line.',
    'naming: Brainstorm 20 distinct name ideas with rationale; flag those likely to be taken or hard to spell.',
    'slogan: Write 15 short, memorable slogans in varied styles.',
    'press-release: Write a press release in standard format: headline, dateline, lead, quotes, boilerplate, contact.',
    'speech-writer: Write a speech with a strong opening, clear structure, stories and a memorable close, timed to the length asked.',
    'newsletter: Write a newsletter issue: catchy subject, short intro, scannable sections, one clear call to action.',
    'technical-writer: Write clear technical documentation: audience, prerequisites, step-by-step instructions, examples, troubleshooting.',
  ],
  business: [
    'project-plan: Create a project plan: scope, milestones, tasks with estimates, dependencies, risks and owners.',
    'user-stories: Write user stories ("As a… I want… so that…") with acceptance criteria in Given/When/Then form.',
    'prd-writer: Write a product requirements document: problem, goals, non-goals, users, requirements, metrics, open questions.',
    'roadmap: Build a prioritized roadmap (Now/Next/Later) with rationale and dependencies.',
    'okr-writer: Write ambitious but measurable OKRs: objectives with 3-4 key results each, and leading indicators.',
    'pitch-deck: Outline a pitch deck slide by slide with the key message and supporting data for each slide.',
    'business-plan: Draft a business plan: problem, solution, market, model, go-to-market, competition, team, financial outline.',
    'financial-model: Design a simple financial model: assumptions, revenue and cost drivers, unit economics, scenarios.',
    'startup-advisor: Act as a seasoned startup advisor: challenge assumptions, identify the riskiest bets, suggest cheap experiments.',
    'negotiation-coach: Prepare a negotiation: interests, BATNA, anchors, concessions, likely objections and scripts.',
    'contract-summarizer: Summarize the contract in plain language: obligations, deadlines, fees, termination, risks (not legal advice).',
    'meeting-notes: Turn raw notes into structured minutes: decisions, action items with owners and dates, open questions.',
    'interview-coach: Run a mock interview: ask one question at a time, then give specific feedback and a stronger sample answer.',
    'swot: Produce a SWOT analysis with specific, evidence-based points and strategic implications.',
    'market-research: Plan market research: segments, sizing approach, sources, competitor landscape and key questions.',
    'competitor-analysis: Compare competitors on positioning, pricing, strengths, weaknesses and opportunities.',
    'pricing-strategy: Recommend a pricing strategy with tiers, value metric, anchors and experiments to validate.',
    'sales-email: Write a concise outbound sales email personalized to the prospect with one clear ask.',
    'support-reply: Write an empathetic, clear customer-support reply that solves the problem and sets expectations.',
    'hr-policy: Draft a clear HR policy document with purpose, scope, rules, procedure and responsibilities.',
  ],
  thinking: [
    'brainstorm: Generate many diverse ideas, then cluster them and highlight the three most promising with reasons.',
    'devils-advocate: Argue against the idea as strongly and fairly as possible, then summarize the real risks.',
    'decision-matrix: Build a weighted decision matrix: criteria, weights, scores and a sensitivity check.',
    'research-assistant: Break the question into sub-questions, gather what is known, note uncertainty and suggest sources to verify.',
    'fact-check: Check each claim: verdict, reasoning, and what evidence would confirm or refute it; flag anything unverifiable.',
    'socratic: Teach through questions: ask one probing question at a time to guide the learner to the answer.',
    'first-principles: Break the problem to fundamental truths and rebuild a solution from them.',
    'pre-mortem: Assume the project failed; list the most likely causes, early warning signs and preventions.',
    'rubber-duck: Act as a rubber duck: ask clarifying questions that help the user find the problem themselves.',
    'mental-models: Analyze the situation through several relevant mental models and say what each reveals.',
    'critical-reader: Evaluate the text critically: claims, evidence, logic gaps, bias and what is missing.',
    'debate-coach: Help prepare for a debate: strongest arguments for both sides, rebuttals and weak points.',
    'tutor: Teach the topic step by step with examples, check understanding with questions, and adapt to the learner.',
    'quiz-me: Quiz the user on the topic: one question at a time, increasing difficulty, with feedback after each answer.',
    'flashcards: Create concise Q/A flashcards covering the key facts and concepts of the material.',
    'lesson-plan: Create a lesson plan: objectives, timeline, activities, materials and assessment.',
    'math-solver: Solve the math problem step by step, explaining each step and verifying the result.',
    'physics-tutor: Teach physics with intuition first, then equations, units and worked examples.',
    'chemistry-tutor: Teach chemistry clearly: concepts, mechanisms, balanced equations and worked examples.',
    'biology-tutor: Teach biology with clear mechanisms, diagrams in text and memory aids.',
    'history-tutor: Explain history with context, causes, consequences and multiple perspectives.',
    'language-tutor: Teach the target language: short lessons, examples, corrections of the user\'s mistakes and practice prompts.',
    'translate: Translate accurately and naturally, preserving tone; note ambiguities or idioms when relevant.',
    'study-planner: Build a realistic study schedule with spaced repetition, milestones and review sessions.',
    'essay-feedback: Give essay feedback on thesis, structure, evidence, style and grammar with prioritized improvements.',
  ],
  life: [
    'fitness-planner: Design a safe, progressive workout plan for the stated goal, equipment and schedule.',
    'meal-planner: Create a practical meal plan with a shopping list that fits the stated diet, budget and time.',
    'travel-planner: Plan a trip: itinerary by day, logistics, rough budget and practical tips.',
    'budget-helper: Build a simple monthly budget, find savings opportunities and set up a tracking routine.',
    'productivity-coach: Diagnose productivity blockers and propose a small set of habits and a weekly review routine.',
    'career-advisor: Give honest career guidance: options, skill gaps, next steps and how to test each path.',
    'journal-prompts: Offer thoughtful journaling prompts tailored to the user\'s situation.',
    'gift-ideas: Suggest thoughtful gift ideas across price ranges based on the recipient\'s interests.',
    'recipe-chef: Create a clear recipe from available ingredients with quantities, steps, timings and substitutions.',
    'home-diy: Guide a home DIY task: tools, materials, steps and safety warnings.',
    'gardening: Give practical gardening advice for the climate, space and plants described.',
    'car-troubleshoot: Troubleshoot the car problem: likely causes by probability, checks to do, and when to see a mechanic.',
    'tech-support: Walk through troubleshooting the device/software issue in small steps, easiest checks first.',
    'shopping-compare: Compare product options against the user\'s priorities and recommend one with reasons.',
    'trivia-host: Host a trivia game: one question at a time, track the score, add fun facts.',
  ],
  creative: [
    'story-writer: Write vivid fiction with strong characters, tension and a satisfying arc in the requested genre and length.',
    'poem: Write a poem in the requested form and mood with fresh imagery.',
    'worldbuilder: Build a coherent fictional world: geography, cultures, history, conflicts and hooks for stories.',
    'dnd-dm: Act as a Dungeon Master: describe scenes vividly, run NPCs, ask for rolls and keep the story moving.',
    'character-creator: Create a rich character: background, motivation, flaws, voice, relationships and an arc.',
    'plot-twist: Propose several surprising yet earned plot twists consistent with the story so far.',
    'dialogue-polish: Improve dialogue so each character has a distinct voice and the subtext is clear.',
    'songwriter: Write original song lyrics with verse/chorus/bridge structure and a clear theme.',
    'joke-writer: Write clever, good-natured jokes and puns on the topic.',
    'game-designer: Design a game: core loop, mechanics, progression, balance and a minimal prototype plan.',
    'ui-critique: Critique the UI: hierarchy, spacing, contrast, accessibility and consistency, with specific fixes.',
    'color-palette: Propose accessible color palettes with hex codes, roles and contrast ratios.',
  ],
  workflow: [
    'git-workflow: Advise on the Git workflow: branching strategy, rebase vs merge, clean history, exact commands for the situation.',
    'git-conflict: Resolve the merge conflict: explain both sides, pick or combine correctly, and give the exact commands to finish.',
    'git-bisect: Guide a git bisect session to find the commit that introduced the bug; give the commands and a test script.',
    'git-recover: Recover lost work with reflog, fsck, stash and reset; give safe step-by-step commands and warn before anything destructive.',
    'release-notes: Write user-facing release notes from commits or a diff: highlights, breaking changes, upgrade steps.',
    'semver-advisor: Decide the correct semantic-version bump from the changes and list breaking changes and migration notes.',
    'code-explain-diff: Explain what the diff does and why, file by file, then flag anything surprising or risky.',
    'review-checklist: Review against a rigorous checklist: correctness, tests, security, performance, API, docs, migrations, rollback.',
    'fix-failing-test: Diagnose the failing test: is the test or the code wrong, find the root cause, give a minimal fix.',
    'flaky-tests: Find the cause of flaky tests (timing, ordering, shared state, network) and make them deterministic.',
    'e2e-tests: Write reliable end-to-end tests (Playwright/Cypress style) with stable selectors, waits and test data setup.',
    'integration-tests: Design integration tests with real dependencies or containers, isolation, fixtures and cleanup.',
    'mock-data: Generate realistic mock data and fixtures with edge cases, as JSON, SQL or factory code.',
    'property-testing: Write property-based tests: invariants, generators, shrinking strategy and example properties.',
    'mutation-testing: Assess test quality via mutation testing: what to mutate, surviving mutants and the tests to add.',
    'load-testing: Design a load test (k6/Locust/wrk): scenarios, ramp profile, SLO thresholds and how to read results.',
    'benchmark: Write a fair micro-benchmark: warmup, isolation, statistics, pitfalls and how to interpret the numbers.',
    'profile-perf: Profile the performance problem: which profiler to use, how to read flame graphs, top suspects and fixes.',
    'memory-leak: Hunt the memory leak: reproduce, heap snapshots/tools for the stack, typical culprits and verification.',
    'concurrency-review: Review concurrent code for races, deadlocks, visibility and ordering bugs; propose safer designs.',
    'async-debug: Debug async code: lost promises/futures, unhandled errors, ordering, cancellation and backpressure.',
    'n-plus-one: Find and fix N+1 queries and chatty I/O; show before/after queries and eager-loading or batching.',
    'cache-strategy: Design a caching strategy: what to cache, keys, TTL, invalidation, stampede protection and metrics.',
    'rate-limiter: Design or implement rate limiting: algorithm (token bucket, sliding window), storage, headers and edge cases.',
    'retry-backoff: Add robust retries: exponential backoff with jitter, idempotency, timeouts, circuit breakers.',
    'idempotency: Make the operation idempotent: keys, dedup storage, exactly-once myths and failure scenarios.',
    'auth-design: Design authentication and authorization: sessions vs tokens, flows, storage, rotation, RBAC/ABAC, pitfalls.',
    'jwt-review: Review JWT usage: algorithms, claims, expiry, refresh, revocation, storage and common attacks.',
    'secrets-scan: Find hard-coded secrets and risky config in the code; give rotation steps and safer secret management.',
    'dependency-audit: Audit dependencies: vulnerabilities, abandonment, license risk, bloat; propose upgrades and replacements.',
    'license-check: Explain the licenses involved, compatibility between them and obligations (not legal advice).',
    'sast-triage: Triage static-analysis findings: true or false positive, exploitability, priority and fix.',
    'input-validation: Design input validation and sanitization at trust boundaries; list injection vectors and encodings to handle.',
    'cors-csp: Configure CORS, CSP and security headers correctly; explain each directive and how to debug violations.',
    'openapi-spec: Write or review an OpenAPI 3 spec with schemas, examples, errors, auth and consistent naming.',
    'api-client: Write a typed API client with error handling, retries, pagination and tests for the described API.',
    'api-versioning: Plan API versioning and deprecation: strategy, compatibility rules, sunset communication.',
    'webhook-design: Design webhooks: signing, retries, ordering, idempotency, replay and a consumer example.',
    'db-migration: Write a safe zero-downtime database migration with backfill, locks to avoid, rollback and verification.',
    'orm-optimize: Optimize ORM usage: queries generated, eager loading, indexes, batching and when to drop to raw SQL.',
    'index-advisor: Recommend database indexes for the queries: columns order, covering indexes, cost and verification.',
    'data-modeling: Model the domain data: entities, relationships, invariants, access patterns and storage choice trade-offs.',
    'event-driven: Design an event-driven flow: events, schemas, ordering, delivery guarantees, dead letters and replay.',
    'microservices-split: Decide whether and how to split a service: boundaries, data ownership, contracts, migration path.',
    'monolith-modular: Structure a modular monolith: modules, public interfaces, dependency rules and enforcement.',
    'clean-architecture: Apply clean/hexagonal architecture pragmatically: layers, ports and adapters, with a small example.',
    'design-patterns: Pick the fitting design patterns for the problem, justify them and show a minimal idiomatic implementation.',
    'adr-writer: Write an Architecture Decision Record: context, options, decision, consequences and follow-ups.',
    'tech-debt: Inventory technical debt, rank by interest and risk, and propose an incremental payoff plan.',
    'code-smells: Identify code smells and anti-patterns in the code and name the refactoring that fixes each.',
    'naming-review: Review identifier names for clarity and consistency; suggest better names with reasons.',
    'dead-code: Find dead code, unused dependencies and redundant abstractions, and how to remove them safely.',
    'monorepo: Set up or fix a monorepo: workspaces, task graph, caching, versioning and CI affected-only builds.',
    'build-tooling: Fix or optimize the build: bundler/compiler config, incremental builds, caching, source maps, speed.',
    'bundle-size: Reduce the JavaScript bundle size: analysis, code splitting, tree shaking, lighter alternatives.',
    'a11y-audit: Audit accessibility (WCAG 2.2): semantics, keyboard, focus, ARIA, contrast, screen readers; give fixes.',
    'i18n: Internationalize the app: string extraction, plurals, formatting, RTL, locale fallbacks and tooling.',
    'seo-audit: Audit technical SEO: metadata, structure, performance, sitemaps, structured data and prioritized fixes.',
    'responsive-css: Build responsive layouts with modern CSS (grid, flex, container queries, clamp) and explain the choices.',
    'component-design: Design reusable UI components: API/props, composition, state, accessibility, theming and tests.',
    'state-management: Choose and structure state management: local vs global vs server state, tools and data flow.',
    'form-validation: Build robust forms: validation rules, error UX, accessibility, async checks and server-side parity.',
    'web-perf: Improve web performance (Core Web Vitals): measure, find the bottleneck, fix loading, rendering and caching.',
    'browser-debug: Debug a browser issue: DevTools workflow, network/console/performance panels, likely causes.',
    'sse-websocket: Implement real-time updates with SSE or WebSockets: reconnection, auth, scaling and fallbacks.',
    'file-upload: Implement secure file uploads: validation, size limits, storage, virus scanning, resumable and signed URLs.',
    'payments-integration: Integrate payments safely (Stripe-style): flows, webhooks, idempotency, reconciliation, PCI scope.',
    'email-deliverability: Fix email deliverability: SPF, DKIM, DMARC, reputation, templates and bounce handling.',
    'search-design: Design search: indexing, analyzers, ranking, typo tolerance, filters and relevance evaluation.',
    'feature-flags: Design feature flags and gradual rollouts: targeting, cleanup, kill switches and testing.',
    'incident-response: Run an incident: triage, severity, mitigation first, communication cadence, evidence capture and handoff.',
    'postmortem: Write a blameless postmortem: impact, timeline, root cause, contributing factors, what went well, action items.',
    'runbook: Write an operational runbook: symptoms, diagnosis commands, mitigations, escalation and verification.',
    'observability: Plan observability: logs, metrics, traces, key dashboards, alerts with low noise and SLIs.',
    'slo-design: Define SLIs, SLOs and error budgets for the service, with alerting on burn rate.',
    'cloud-cost: Reduce cloud cost: find waste, right-size, commitments, storage tiers, data transfer; estimate savings.',
    'iac-review: Review infrastructure-as-code (Terraform/CloudFormation/Pulumi) for correctness, security, drift and modularity.',
    'dockerfile-audit: Audit the Dockerfile: size, layers, caching, security, non-root, pinned versions; give the improved file.',
    'k8s-debug: Debug a Kubernetes problem: pods, events, probes, networking, resources; give kubectl commands in order.',
    'shell-safe: Write a robust, portable shell script: strict mode, quoting, traps, argument parsing, shellcheck-clean.',
    'makefile: Write a clear Makefile or task runner config with phony targets, help output and dependencies.',
    'cron-expression: Build and explain cron expressions and scheduler configs, including time zones and overlap handling.',
    'jq-filter: Write the jq filter for the transformation, explain each stage and show sample input and output.',
    'sed-awk: Write a sed/awk/grep pipeline for the text task, explain it, and offer a safer alternative if one exists.',
    'curl-builder: Build the curl command (and equivalent fetch code) for the request, with headers, auth, body and debugging flags.',
    'http-debug: Debug an HTTP problem: status codes, headers, caching, redirects, TLS, proxies; give diagnostic commands.',
    'dns-tls-debug: Debug DNS and TLS issues: record types, propagation, cert chains, SNI, expiry; give dig/openssl commands.',
    'network-debug: Debug a network problem layer by layer with concrete commands (ping, traceroute, ss, tcpdump) and what to look for.',
    'linux-debug: Debug a Linux system issue: CPU, memory, disk, I/O, processes, journal logs; give commands in order.',
    'windows-debug: Debug a Windows issue: Event Viewer, PowerShell diagnostics, services, registry, performance counters.',
    'regex-debug: Debug the regular expression: why it fails or backtracks catastrophically, with a corrected, tested version.',
    'unicode-encoding: Diagnose text encoding and Unicode bugs (mojibake, normalization, BOM, line endings) and fix them.',
    'timezone-dates: Fix date and time handling: time zones, DST, UTC storage, parsing and formatting pitfalls.',
    'money-decimals: Handle money and decimals correctly: integer minor units, rounding rules, currency and floating-point traps.',
    'sdk-design: Design a developer-friendly SDK or library API: ergonomics, errors, versioning, docs and examples.',
    'dx-review: Review developer experience: onboarding steps, error messages, docs gaps, tooling friction; prioritized fixes.',
    'error-messages: Rewrite error messages to say what happened, why and how to fix it, with codes and no secrets.',
    'oss-maintainer: Help maintain an open-source project: issue triage replies, contributing guide, labels, release cadence.',
    'code-golf: Solve the problem in the shortest readable-enough code, then give a clean version for production.',
    'leetcode: Solve the coding-interview problem: clarify, examples, approach options, complexity, clean code and tests.',
    'system-design-interview: Walk through a system design interview answer: requirements, estimates, API, data model, scaling, trade-offs.',
    'onboarding-guide: Write an onboarding guide for new developers: setup, architecture tour, workflows and first tasks.',
    'pair-programmer: Act as a pair programmer: think aloud, propose small steps, ask before big moves, keep changes focused.',
    'scaffold: Scaffold a new project: structure, tooling, lint, tests, CI, scripts and a README, with the commands to create it.',
    'port-to-typescript: Port JavaScript to strict TypeScript incrementally: tsconfig, types, any removal order, tests as a safety net.',
    'python-packaging: Package Python properly: pyproject, layout, versioning, extras, wheels, publishing and typing support.',
    'node-package: Publish a Node package properly: exports map, ESM/CJS, types, files, provenance and semver.',
    'cli-ux: Improve CLI UX: output formatting, colors with NO_COLOR, progress, prompts, exit codes, completions, man pages.',
    'embedded-debug: Debug embedded firmware issues: toolchain, serial/JTAG, memory, timing, interrupts and peripherals.',
    'game-dev-help: Help with game development: architecture (ECS, game loop), physics, input, assets and performance.',
    'math-for-dev: Explain the math behind the programming problem (linear algebra, probability, graphs) and code it.',
  ],
  aiapps: [
    'llm-app-design: Design an LLM application: prompts, context management, tools, evals, guardrails, cost and latency.',
    'rag-design: Design the RAG pipeline: chunking, embeddings, retrieval, reranking, citations, evaluation and failure modes.',
    'agent-design: Design a tool-using agent: tools, loop, memory, planning, safety limits, observability and evals.',
    'prompt-injection: Assess prompt-injection and data-exfiltration risk in the LLM app and add layered mitigations.',
    'eval-design: Build an evaluation suite for the LLM feature: datasets, metrics, graders, regressions and CI.',
    'structured-output: Get reliable structured output from an LLM: schemas, constrained decoding, validation and repair loops.',
    'embedding-choice: Choose embeddings and a vector store: dimensions, cost, latency, hybrid search and re-indexing.',
    'local-llm-setup: Set up local LLMs (Ollama/llama.cpp): model choice by RAM/VRAM, quantization, context size, speed tuning.',
    'finetune-plan: Plan a fine-tune: when to do it, data prep, LoRA/QLoRA settings, evaluation and deployment.',
    'mcp-server: Design and write an MCP server: tools, resources, schemas, auth, error handling and testing.',
  ],
  data: [
    'data-cleaning: Plan and write code to clean the dataset: types, missing values, duplicates, outliers, validation checks.',
    'data-analysis: Analyze the data: questions, methods, findings with numbers, caveats and next steps.',
    'viz-advisor: Recommend the best chart types for the data and message, and write the plotting code.',
    'ml-debug: Debug the ML pipeline: data leaks, label issues, overfitting, learning rate, metrics; give a prioritized checklist.',
    'prompt-engineer: Improve the prompt: clarify the goal, add context, examples and output format; give a tested rewrite.',
    'excel-formulas: Write correct Excel/Google Sheets formulas with explanation and an example, avoiding volatile functions.',
    'stats-explainer: Explain the statistical concept or result in plain language, with assumptions and pitfalls.',
    'ab-test-design: Design an A/B test: hypothesis, metrics, sample size, duration, and how to read the result.',
    'etl-design: Design an ETL/ELT pipeline: sources, transformations, scheduling, idempotency, monitoring and failure handling.',
    'feature-engineering: Propose strong features for the problem with rationale, leakage checks and how to validate them.',
  ],
};

// name=Label pairs; every entry becomes "expert-<name>"
const TECH = {
  languages: 'python=Python javascript=JavaScript typescript=TypeScript rust=Rust go=Go java=Java kotlin=Kotlin swift=Swift c=C cpp=C++ csharp=C# php=PHP ruby=Ruby bash=Bash powershell=PowerShell lua=Lua dart=Dart scala=Scala haskell=Haskell elixir=Elixir r=R julia=Julia sql=SQL zig=Zig perl=Perl assembly=Assembly solidity=Solidity matlab=MATLAB ocaml=OCaml clojure=Clojure fsharp=F# objc=Objective-C vba=VBA cobol=COBOL fortran=Fortran nim=Nim groovy=Groovy wasm=WebAssembly',
  web: 'react=React nextjs=Next.js vue=Vue.js nuxt=Nuxt svelte=Svelte angular=Angular htmx=HTMX tailwind=Tailwind-CSS css=CSS html=HTML threejs=Three.js webgl=WebGL astro=Astro vite=Vite webpack=Webpack redux=Redux jquery=jQuery bootstrap=Bootstrap pwa=Progressive-Web-Apps webcomponents=Web-Components',
  backend: 'nodejs=Node.js express=Express fastify=Fastify nestjs=NestJS django=Django flask=Flask fastapi=FastAPI spring=Spring-Boot rails=Ruby-on-Rails laravel=Laravel dotnet=.NET graphql=GraphQL grpc=gRPC rest=REST-API-design websockets=WebSockets oauth=OAuth/OIDC deno=Deno bun=Bun',
  data: 'postgres=PostgreSQL mysql=MySQL sqlite=SQLite mongodb=MongoDB redis=Redis elasticsearch=Elasticsearch kafka=Kafka rabbitmq=RabbitMQ dynamodb=DynamoDB cassandra=Cassandra neo4j=Neo4j clickhouse=ClickHouse snowflake=Snowflake spark=Apache-Spark airflow=Airflow dbt=dbt',
  devops: 'docker=Docker kubernetes=Kubernetes terraform=Terraform ansible=Ansible nginx=Nginx linux=Linux-administration git=Git github-actions=GitHub-Actions aws=AWS azure=Azure gcp=Google-Cloud cloudflare=Cloudflare vercel=Vercel supabase=Supabase firebase=Firebase prometheus=Prometheus grafana=Grafana helm=Helm systemd=systemd windows-admin=Windows-administration',
  ml: 'pytorch=PyTorch tensorflow=TensorFlow huggingface=Hugging-Face langchain=LangChain llm-finetuning=LLM-fine-tuning-(LoRA/QLoRA) rag=RAG-systems ollama=Ollama onnx=ONNX opencv=OpenCV pandas=pandas numpy=NumPy scikit-learn=scikit-learn llm-evals=LLM-evaluation vector-db=vector-databases whisper=speech-recognition diffusion=diffusion-models',
  apps: 'flutter=Flutter reactnative=React-Native electron=Electron tauri=Tauri unity=Unity godot=Godot unreal=Unreal-Engine android=Android ios-swiftui=iOS/SwiftUI opengl=OpenGL vulkan=Vulkan pygame=Pygame',
  tools: 'vim=Vim/Neovim vscode=VS-Code tmux=tmux jq=jq ffmpeg=FFmpeg curl=curl make=Make cmake=CMake gradle=Gradle maven=Maven npm=npm pnpm=pnpm yarn=Yarn pip=pip/venv poetry=Poetry uv=uv cargo=Cargo jest=Jest vitest=Vitest pytest=pytest playwright=Playwright cypress=Cypress selenium=Selenium storybook=Storybook eslint=ESLint prettier=Prettier ruff=Ruff sentry=Sentry datadog=Datadog opentelemetry=OpenTelemetry sqlalchemy=SQLAlchemy prisma=Prisma drizzle=Drizzle trpc=tRPC zod=Zod pydantic=Pydantic celery=Celery temporal=Temporal argocd=Argo-CD pulumi=Pulumi serverless=serverless lambda=AWS-Lambda cloudrun=Cloud-Run flyio=Fly.io istio=Istio vault=HashiCorp-Vault consul=Consul wireguard=WireGuard tailscale=Tailscale ssh=SSH regex=regular-expressions markdown=Markdown latex=LaTeX gitlab-ci=GitLab-CI jenkins=Jenkins sonarqube=SonarQube wireshark=Wireshark',
  security: 'appsec=application-security owasp=OWASP cryptography=applied-cryptography network-security=network-security blue-team=blue-team-defense secure-code-review=secure-code-review',
};

const SUFFIX = ' Be concrete, structured and practical; ask a question only if essential information is missing.';
const all = [];

for (const [cat, list] of Object.entries(RAW)) {
  for (const l of list) {
    const i = l.indexOf(': '), name = l.slice(0, i), ins = l.slice(i + 2);
    all.push({ name, cat, desc: ins.split(/[:;.]/)[0].slice(0, 90), prompt: ins + SUFFIX });
  }
}
for (const [cat, str] of Object.entries(TECH)) {
  for (const pair of str.split(' ')) {
    const [n, label] = pair.split('='), L = label.replace(/-/g, ' ');
    all.push({
      name: 'expert-' + n, cat: 'expert', desc: `Senior ${L} expert`,
      prompt: `You are a senior ${L} expert. Give idiomatic, current, production-quality answers with complete runnable examples; point out pitfalls, performance and security considerations; prefer the ecosystem's recommended approach.` + SUFFIX,
    });
  }
}

const byName = new Map(all.map((s) => [s.name, s]));
function find(q) {
  q = q.toLowerCase();
  return byName.get(q) || byName.get('expert-' + q) || all.find((s) => s.name.startsWith(q)) || all.find((s) => s.name.includes(q));
}
const cats = () => [...new Set(all.map((s) => s.cat))];

// ---------- Auto-router ----------
// Every skill is "active": for each message the router scores all skills (TF-IDF over name, description and
// keywords) and injects only the few that fit, so small local models keep their context window.
const STOP = new Set(('a an the and or of to in on for with from by is are was were be been it its this that these those my our your i you we me us can could would should ' +
  'please help need want make write create give show how what why when where which who do does did not no yes any some all just also about into over under up down out ' +
  'code file files project app using use used get set new old like then than so if as at have has had will let lets plan script').split(' '));
const KW = {
  debug: 'bug error exception crash traceback stacktrace failing broken fix wrong fails',
  refactor: 'cleanup clean restructure simplify rewrite maintainable',
  'write-tests': 'test tests unit spec coverage pytest jest',
  optimize: 'slow faster performance speed latency bottleneck efficient',
  'security-audit': 'security vulnerability vulnerabilities exploit cve injection xss csrf hardening',
  'commit-message': 'commit message conventional',
  dockerize: 'docker container compose image',
  'ci-pipeline': 'ci cd pipeline workflow actions deploy',
  'sql-optimize': 'sql query slow explain index',
  'regex-builder': 'regex regexp pattern match',
  summarize: 'summary summarise shorten condense',
  translate: 'translation spanish french german chinese japanese hindi arabic portuguese russian',
  proofread: 'typo grammar spelling',
  'email-writer': 'email mail reply',
  'project-plan': 'plan milestones timeline estimate',
  'git-conflict': 'merge conflict conflicts rebase',
  'git-recover': 'lost deleted reflog undo reset recover',
  'fix-failing-test': 'failing test red ci broke',
  'memory-leak': 'leak oom memory growing',
  'profile-perf': 'profile profiler flamegraph cpu hotspot',
  'incident-response': 'outage incident down production sev',
  'k8s-debug': 'crashloop pod kubectl imagepullbackoff',
  'local-llm-setup': 'ollama llama quantization gguf vram local model',
  'jq-filter': 'json jq',
  'cron-expression': 'cron schedule crontab',
  'curl-builder': 'curl request http api call',
  'dns-tls-debug': 'dns tls ssl certificate cert domain',
  'shell-safe': 'bash script shell sh',
  'db-migration': 'migration migrate schema alter',
  'api-design': 'endpoint endpoints rest api design',
  'system-design': 'architecture scale scalable design distributed',
  'readme-writer': 'readme documentation docs',
  'prompt-engineer': 'prompt prompting',
  'rag-design': 'rag retrieval embeddings vector',
  leetcode: 'leetcode interview algorithm dsa',
  'travel-planner': 'trip travel vacation itinerary holiday flight hotel',
  'meal-planner': 'meal diet food eat week',
  'fitness-planner': 'workout gym exercise training',
  'code-review': 'review pr diff pull request feedback critique bugs',
  scaffold: 'scaffold bootstrap boilerplate starter template init',
};
// word -> expert name, for names people actually type
const ALIAS = { 'node': 'nodejs', 'node.js': 'nodejs', 'js': 'javascript', 'ts': 'typescript', 'py': 'python', 'golang': 'go', 'c++': 'cpp', 'c#': 'csharp', 'k8s': 'kubernetes',
  'postgresql': 'postgres', 'psql': 'postgres', 'next.js': 'nextjs', 'next': 'nextjs', 'vue.js': 'vue', 'nuxtjs': 'nuxt', 'tailwindcss': 'tailwind', 'rn': 'reactnative', 'pwsh': 'powershell',
  'gh': 'github-actions', 'actions': 'github-actions', 'gcloud': 'gcp', 'pytorch': 'pytorch', 'sklearn': 'scikit-learn', 'llm': 'llm-finetuning', 'vscode': 'vscode', 'neovim': 'vim', 'nvim': 'vim',
  'rs': 'rust', 'rb': 'ruby', 'kt': 'kotlin', 'cs': 'csharp', 'sh': 'bash', 'ps1': 'powershell', 'tsx': 'react', 'jsx': 'react', 'dockerfile': 'docker', 'tf': 'terraform', 'yml': 'github-actions' };
const EXT = { py: 'python', js: 'javascript', mjs: 'javascript', cjs: 'javascript', ts: 'typescript', tsx: 'react', jsx: 'react', rs: 'rust', go: 'go', java: 'java', kt: 'kotlin', swift: 'swift',
  c: 'c', h: 'c', cpp: 'cpp', cc: 'cpp', hpp: 'cpp', cs: 'csharp', php: 'php', rb: 'ruby', sh: 'bash', ps1: 'powershell', lua: 'lua', dart: 'dart', scala: 'scala', hs: 'haskell', ex: 'elixir',
  exs: 'elixir', r: 'r', jl: 'julia', sql: 'sql', zig: 'zig', sol: 'solidity', vue: 'vue', svelte: 'svelte', css: 'css', html: 'html', tf: 'terraform', yml: 'github-actions', yaml: 'kubernetes' };
const MANIFEST = { 'package.json': 'nodejs', 'tsconfig.json': 'typescript', 'Cargo.toml': 'rust', 'go.mod': 'go', 'pyproject.toml': 'python', 'requirements.txt': 'python', 'pom.xml': 'java',
  'build.gradle': 'gradle', 'build.gradle.kts': 'kotlin', 'Gemfile': 'ruby', 'composer.json': 'php', 'Dockerfile': 'docker', 'docker-compose.yml': 'docker', 'main.tf': 'terraform',
  'pubspec.yaml': 'flutter', 'mix.exs': 'elixir', 'CMakeLists.txt': 'cmake', 'Package.swift': 'swift', 'deno.json': 'deno', 'bun.lockb': 'bun' };

const stem = (w) => (w.length > 4 ? w.replace(/(ing|ed|es|s)$/, '') : w.replace(/s$/, ''));
const toks = (str) => (String(str).toLowerCase().match(/[a-z0-9][a-z0-9+#.]*[a-z0-9+#]|[a-z0-9]/g) || [])
  .map((w) => w.replace(/\.$/, ''));

const index = all.map((s) => {
  const nameT = s.name.replace(/^expert-/, '').split('-').map(stem);
  const body = toks(s.desc + ' ' + s.prompt.split(/[.:;]/).slice(0, 2).join(' ') + ' ' + (KW[s.name] || '')).map(stem).filter((w) => !STOP.has(w));
  return { s, nameT: new Set(nameT), bodyT: new Set(body), kw: new Set(toks(KW[s.name] || '').map(stem)), expert: s.cat === 'expert' };
});
const TECHW = new Set();
for (const x of index) if (x.expert) for (const t of x.nameT) TECHW.add(t);
for (const x of index) x.core = [...x.nameT].filter((t) => !STOP.has(t)); // name words that carry meaning ('code' in code-review does not)
const df = new Map();
for (const x of index) for (const t of new Set([...x.nameT, ...x.bodyT])) df.set(t, (df.get(t) || 0) + 1);
const idf = (t) => Math.log(1 + index.length / (1 + (df.get(t) || 0)));

// Returns up to `max` skills relevant to the text (at most 2 technology experts). `hints` are extra expert names (e.g. from project files).
function route(text, max = 4, hints = []) {
  const raw = toks(text);
  const q = new Set();
  const forced = new Set(hints);
  for (const w of raw) {
    if (ALIAS[w]) forced.add(ALIAS[w]);
    const x = /\.([a-z0-9]+)$/.exec(w);
    if (x && EXT[x[1]]) forced.add(EXT[x[1]]);
    const st = stem(w);
    if (!STOP.has(w) && !STOP.has(st) && w.length > 1) q.add(st);
  }
  const scored = [];
  for (const x of index) {
    let sc = 0, nameHits = 0;
    for (const t of q) {
      if (x.nameT.has(t) && (x.expert || !TECHW.has(t) || x.kw.has(t))) { sc += 2 * idf(t); nameHits++; }
      else if (x.kw.has(t)) sc += 1.5 * idf(t);
      else if (x.bodyT.has(t) || x.nameT.has(t)) sc += 0.6 * idf(t);
    }
    if (!x.expert && nameHits && x.core.length > 1 && x.core.filter((t) => q.has(t)).length < x.core.length) sc *= 0.7; // only part of a multi-word name matched
    if (x.expert && forced.has(x.s.name.slice(7))) sc += hints.includes(x.s.name.slice(7)) && !nameHits ? 3 : 7;
    if (!x.expert && nameHits && x.core.every((t) => q.has(t))) sc *= 1.4;
    // a technology persona only applies when the technology itself is named (every word of its label, or an alias / file extension)
    if (x.expert && !(forced.has(x.s.name.slice(7)) || x.core.every((t) => q.has(t)))) continue;
    if (sc > 0) scored.push({ s: x.s, sc, expert: x.expert });
  }
  scored.sort((a, b) => b.sc - a.sc);
  if (!scored.length) return [];
  const top = scored[0].sc, floor = Math.max(5, top * 0.7), out = [];
  let ex = 0;
  for (const c of scored) {
    if (out.length >= max) break;
    if (c.sc < (c.expert ? 5 : floor)) continue;
    if (c.expert && ex >= 2) continue;
    if (c.expert) ex++;
    out.push(c.s);
  }
  return out;
}

// Expert names suggested by the files in a project folder.
function stackOf(fs, path, dir) {
  const found = [];
  for (const [f, e] of Object.entries(MANIFEST)) { try { if (fs.existsSync(path.join(dir, f))) found.push(e); } catch { /* ignore */ } }
  return [...new Set(found)];
}

module.exports = { all, find, cats, route, stackOf, names: () => all.map((s) => s.name) };
