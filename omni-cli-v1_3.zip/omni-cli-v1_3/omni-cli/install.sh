#!/usr/bin/env sh
# Installs the `omni` command globally (needs Node.js 18+ and npm)
set -e
cd "$(dirname "$0")"
chmod +x bin/omni.js
npm install -g . || { echo "Global install failed; try: sudo npm install -g ."; exit 1; }
echo "Done. Run: omni"
