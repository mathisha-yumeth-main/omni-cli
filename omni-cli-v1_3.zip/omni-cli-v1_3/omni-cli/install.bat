@echo off
cd /d "%~dp0"
call npm install -g .
if errorlevel 1 (echo Install failed) else (echo Done. Open a NEW terminal and run: omni)
pause
