'use strict';
const fs = require('fs'), path = require('path'), os = require('os');
const { exec } = require('child_process');
const kb = require('./kb');

const IGN = new Set(['node_modules', '.git', '__pycache__', '.venv', 'venv', 'dist', 'build', '.next', 'target', '.cache', '.idea', '.vscode']);
const cap = (s, n = 12000) => (s.length > n ? s.slice(0, n / 2) + `\n…[truncated ${s.length - n} chars]…\n` + s.slice(-n / 2) : s);
const abs = (ctx, p) => path.resolve(ctx.cwd, String(p || '.').replace(/^~(?=$|[\\/])/, os.homedir()));
const rel = (ctx, f) => path.relative(ctx.cwd, f).split(path.sep).join('/');

function* walk(dir, depth = 20) {
  let ents;
  try { ents = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
  for (const e of ents) {
    if (IGN.has(e.name)) continue;
    const f = path.join(dir, e.name);
    if (e.isDirectory()) { if (depth > 0) yield* walk(f, depth - 1); } else yield f;
  }
}
const globRe = (g) => new RegExp('^' + g.replace(/[.+^${}()|[\]\\]/g, '\\$&').replace(/\*\*\/?/g, '§')
  .replace(/\*/g, '[^/]*').replace(/\?/g, '[^/]').replace(/§/g, '(?:.*/)?') + '$');
const isBinary = (f) => { try { const b = fs.readFileSync(f).subarray(0, 1000); return b.includes(0); } catch { return true; } };

const html2text = (h) => h.replace(/<(script|style|noscript)[\s\S]*?<\/\1>/gi, '').replace(/<br\s*\/?>|<\/(p|div|li|h\d|tr)>/gi, '\n')
  .replace(/<[^>]+>/g, '').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
  .replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/[ \t]+/g, ' ').replace(/\n\s*\n+/g, '\n\n').trim();

const run = (cmd, ctx, timeout = 60) => new Promise((resolve) => {
  exec(cmd, { cwd: ctx.cwd, timeout: timeout * 1000, maxBuffer: 10 * 1024 * 1024, windowsHide: true }, (err, so, se) => {
    let out = `exit code: ${err ? (err.killed ? 'timeout' : err.code) : 0}\n`;
    if (so) out += '--- stdout ---\n' + so;
    if (se) out += '--- stderr ---\n' + se;
    resolve(out);
  });
});

const GIT_RO = new Set(['status', 'diff', 'log', 'show', 'branch', 'remote', 'blame', 'ls-files', 'rev-parse', 'describe', 'tag']);


// Guess the project's test command from its manifest files.
function testCommand(cwd) {
  const has = (f) => fs.existsSync(path.join(cwd, f));
  if (has('package.json')) {
    try {
      const j = JSON.parse(fs.readFileSync(path.join(cwd, 'package.json'), 'utf8'));
      if (j.scripts && j.scripts.test && !/no test specified/.test(j.scripts.test)) return has('pnpm-lock.yaml') ? 'pnpm test' : has('yarn.lock') ? 'yarn test' : 'npm test';
    } catch { /* fall through */ }
  }
  if (has('Cargo.toml')) return 'cargo test';
  if (has('go.mod')) return 'go test ./...';
  if (has('pyproject.toml') || has('pytest.ini') || has('setup.py') || has('requirements.txt') || has('tox.ini')) return 'python -m pytest -x -q';
  if (has('pom.xml')) return 'mvn -q test';
  if (has('build.gradle') || has('build.gradle.kts')) return has('gradlew') ? './gradlew test' : 'gradle test';
  if (has('mix.exs')) return 'mix test';
  if (has('Gemfile')) return 'bundle exec rake test';
  if (has('composer.json')) return 'vendor/bin/phpunit';
  if (has('Makefile') && /^test\s*:/m.test(fs.readFileSync(path.join(cwd, 'Makefile'), 'utf8'))) return 'make test';
  return '';
}

function lintCommand(cwd) {
  const has = (f) => fs.existsSync(path.join(cwd, f));
  if (has('package.json')) {
    try { const j = JSON.parse(fs.readFileSync(path.join(cwd, 'package.json'), 'utf8')); if (j.scripts && j.scripts.lint) return has('pnpm-lock.yaml') ? 'pnpm run lint' : has('yarn.lock') ? 'yarn lint' : 'npm run lint'; } catch { /* next */ }
    if (['.eslintrc', '.eslintrc.js', '.eslintrc.json', '.eslintrc.cjs', 'eslint.config.js', 'eslint.config.mjs'].some(has)) return 'npx eslint .';
  }
  if (has('Cargo.toml')) return 'cargo clippy';
  if (has('go.mod')) return 'go vet ./...';
  if (has('ruff.toml') || has('.ruff.toml') || (has('pyproject.toml') && /\[tool\.ruff/.test(fs.readFileSync(path.join(cwd, 'pyproject.toml'), 'utf8')))) return 'ruff check .';
  if (has('.flake8') || has('setup.cfg') || has('requirements.txt') || has('pyproject.toml')) return 'python -m flake8 .';
  if (has('Gemfile')) return 'bundle exec rubocop';
  return '';
}

function buildCommand(cwd) {
  const has = (f) => fs.existsSync(path.join(cwd, f));
  if (has('package.json')) {
    try { const j = JSON.parse(fs.readFileSync(path.join(cwd, 'package.json'), 'utf8')); if (j.scripts && j.scripts.build) return has('pnpm-lock.yaml') ? 'pnpm run build' : has('yarn.lock') ? 'yarn build' : 'npm run build'; } catch { /* next */ }
  }
  if (has('Cargo.toml')) return 'cargo build';
  if (has('go.mod')) return 'go build ./...';
  if (has('pom.xml')) return 'mvn -q package -DskipTests';
  if (has('build.gradle') || has('build.gradle.kts')) return has('gradlew') ? './gradlew build -x test' : 'gradle build -x test';
  if (has('CMakeLists.txt')) return 'cmake -S . -B build && cmake --build build';
  if (has('Makefile')) return 'make';
  if (has('pyproject.toml')) return 'python -m build';
  return '';
}

const SYM = [
  /^\s*(?:export\s+)?(?:default\s+)?(?:async\s+)?(?:function\*?|class|interface|enum|type)\s+([A-Za-z_$][\w$]*)/,
  /^\s*(?:export\s+)?(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?(?:\([^)]*\)|[A-Za-z_$][\w$]*)\s*=>/,
  /^\s*(?:async\s+)?def\s+([A-Za-z_]\w*)/, /^\s*class\s+([A-Za-z_]\w*)/,
  /^\s*func\s+(?:\([^)]*\)\s*)?([A-Za-z_]\w*)/, /^\s*(?:pub(?:\([^)]*\))?\s+)?(?:async\s+)?(?:fn|struct|enum|trait|impl)\s+([A-Za-z_]\w*)/,
  /^\s*(?:public|private|protected|internal|static|final|abstract|sealed|\s)*(?:class|interface|enum|record)\s+([A-Za-z_]\w*)/,
];

const TOOLS = [
  { name: 'read_file', sig: 'read_file(path, start?, end?)', desc: 'Read a text file with line numbers (optional 1-based line range).',
    run: (a, ctx) => {
      const f = abs(ctx, a.path), ls = fs.readFileSync(f, 'utf8').split('\n');
      const s = Math.max(1, a.start || 1), e = Math.min(ls.length, a.end || ls.length);
      return ls.slice(s - 1, e).map((l, i) => `${String(s + i).padStart(5)}  ${l}`).join('\n');
    } },
  { name: 'write_file', sig: 'write_file(path, content)', desc: 'Create or overwrite a file (parent folders are created).',
    danger: (a) => `write ${a.path} (${String(a.content || '').length} chars)`,
    run: (a, ctx) => { const f = abs(ctx, a.path); fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, String(a.content ?? '')); return `Wrote ${a.path}`; } },
  { name: 'edit_file', sig: 'edit_file(path, old, new, all?)', desc: 'Replace exact text in a file. "old" must match exactly once unless all=true.',
    danger: (a) => `edit ${a.path}\n    - ${String(a.old).split('\n')[0].slice(0, 90)}\n    + ${String(a.new).split('\n')[0].slice(0, 90)}`,
    run: (a, ctx) => {
      const f = abs(ctx, a.path), src = fs.readFileSync(f, 'utf8'), n = src.split(a.old).length - 1;
      if (!a.old) throw new Error('"old" is empty');
      if (n === 0) throw new Error('"old" text not found');
      if (n > 1 && !a.all) throw new Error(`"old" matches ${n} times; add more context or set all=true`);
      fs.writeFileSync(f, src.split(a.old).join(a.new ?? '')); return `Edited ${a.path} (${n} replacement${n > 1 ? 's' : ''})`;
    } },
  { name: 'list_dir', sig: 'list_dir(path?)', desc: 'List files and folders in a directory.',
    run: (a, ctx) => fs.readdirSync(abs(ctx, a.path), { withFileTypes: true }).map((e) => (e.isDirectory() ? e.name + '/' : e.name)).join('\n') || '(empty)' },
  { name: 'tree', sig: 'tree(path?, depth?)', desc: 'Show a directory tree (default depth 3).',
    run: (a, ctx) => {
      const out = [];
      const rec = (d, pre, depth) => {
        if (depth < 0 || out.length > 400) return;
        let es; try { es = fs.readdirSync(d, { withFileTypes: true }).filter((e) => !IGN.has(e.name)); } catch { return; }
        es.forEach((e, i) => { const last = i === es.length - 1; out.push(pre + (last ? '└─ ' : '├─ ') + e.name + (e.isDirectory() ? '/' : '')); if (e.isDirectory()) rec(path.join(d, e.name), pre + (last ? '   ' : '│  '), depth - 1); });
      };
      rec(abs(ctx, a.path), '', (a.depth || 3) - 1); return out.join('\n') || '(empty)';
    } },
  { name: 'glob', sig: 'glob(pattern)', desc: 'Find files by glob pattern, e.g. "src/**/*.js".',
    run: (a, ctx) => {
      const re = globRe(String(a.pattern)), base = !String(a.pattern).includes('/'), out = [];
      for (const f of walk(ctx.cwd)) { const r = rel(ctx, f); if (re.test(base ? path.basename(f) : r)) out.push(r); if (out.length >= 300) break; }
      return out.join('\n') || 'No matches';
    } },
  { name: 'grep', sig: 'grep(pattern, path?, include?, ignore_case?)', desc: 'Search file contents with a regex; include is a glob like "*.py".',
    run: (a, ctx) => {
      const re = new RegExp(a.pattern, a.ignore_case ? 'i' : ''), inc = a.include ? globRe(a.include) : null, out = [];
      const root = abs(ctx, a.path);
      const it = fs.statSync(root).isFile() ? [root] : walk(root);
      for (const f of it) {
        if (inc && !inc.test(path.basename(f))) continue;
        let st; try { st = fs.statSync(f); } catch { continue; }
        if (st.size > 1e6 || isBinary(f)) continue;
        fs.readFileSync(f, 'utf8').split('\n').forEach((l, i) => { if (re.test(l) && out.length < 120) out.push(`${rel(ctx, f)}:${i + 1}: ${l.trim().slice(0, 200)}`); });
        if (out.length >= 120) break;
      }
      return out.join('\n') || 'No matches';
    } },
  { name: 'read_many', sig: 'read_many(paths:[...], max_lines?)', desc: 'Read several files at once (first max_lines lines each, default 200).',
    run: (a, ctx) => (a.paths || []).slice(0, 12).map((p) => {
      try { const ls = fs.readFileSync(abs(ctx, p), 'utf8').split('\n'), n = a.max_lines || 200; return `=== ${p} (${ls.length} lines) ===\n` + ls.slice(0, n).map((l, i) => `${String(i + 1).padStart(5)}  ${l}`).join('\n') + (ls.length > n ? `\n… ${ls.length - n} more lines` : ''); }
      catch (e) { return `=== ${p} ===\nError: ${e.message}`; }
    }).join('\n\n') },
  { name: 'symbols', sig: 'symbols(path?, query?)', desc: 'Outline functions/classes/types defined in a file or folder (JS/TS/Python/Go/Rust/Java/C#...). Optional name filter.',
    run: (a, ctx) => {
      const root = abs(ctx, a.path), q = a.query ? String(a.query).toLowerCase() : '', out = [];
      const it = fs.statSync(root).isFile() ? [root] : walk(root);
      for (const f of it) {
        if (!/\.(js|mjs|cjs|jsx|ts|tsx|py|go|rs|java|kt|cs|php|rb|swift|dart|scala)$/i.test(f)) continue;
        let st; try { st = fs.statSync(f); } catch { continue; }
        if (st.size > 1e6) continue;
        fs.readFileSync(f, 'utf8').split('\n').forEach((l, i) => {
          if (out.length >= 300) return;
          for (const re of SYM) { const m = re.exec(l); if (m) { if (!q || m[1].toLowerCase().includes(q)) out.push(`${rel(ctx, f)}:${i + 1}  ${l.trim().slice(0, 110)}`); break; } }
        });
      }
      return out.join('\n') || 'No symbols found';
    } },
  { name: 'run_tests', sig: 'run_tests(command?)', desc: 'Run the project test suite (auto-detects npm/pytest/cargo/go/maven/gradle/make) and return the output.',
    danger: (a) => `run tests: ${a.command || '(auto-detected test command)'}`,
    run: (a, ctx) => { const c = a.command || testCommand(ctx.cwd); if (!c) throw new Error('No test command detected; pass command'); return run(c, ctx, 300).then((r) => `$ ${c}\n${r}`); } },
  { name: 'run_command', sig: 'run_command(command, timeout?)', desc: 'Run a shell command (cmd/PowerShell on Windows, sh on Linux). timeout in seconds, default 60.',
    danger: (a) => `run: ${a.command}`, run: (a, ctx) => run(String(a.command), ctx, a.timeout || 60) },
  { name: 'git', sig: 'git(args)', desc: 'Run a git command, e.g. git(args:"status -s"). Read-only subcommands need no approval.',
    danger: (a) => (GIT_RO.has(String(a.args).trim().split(/\s+/)[0]) ? false : `git ${a.args}`),
    run: (a, ctx) => run('git ' + a.args, ctx, 60) },
  { name: 'web_fetch', sig: 'web_fetch(url)', desc: 'Download a web page and return readable text.',
    run: async (a) => { const r = await fetch(a.url, { headers: { 'user-agent': 'Mozilla/5.0 omni-cli' }, signal: AbortSignal.timeout(20000) }); const t = await r.text(); return `HTTP ${r.status}\n` + (/html/i.test(r.headers.get('content-type') || '') ? html2text(t) : t); } },
  { name: 'web_search', sig: 'web_search(query)', desc: 'Search the web (DuckDuckGo) and return titles, URLs and snippets.',
    run: async (a) => {
      const r = await fetch('https://html.duckduckgo.com/html/?q=' + encodeURIComponent(a.query), { headers: { 'user-agent': 'Mozilla/5.0 omni-cli' }, signal: AbortSignal.timeout(20000) });
      const h = await r.text(), out = [];
      const re = /<a[^>]*class="result__a"[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>[\s\S]*?class="result__snippet"[^>]*>([\s\S]*?)<\/a>/g;
      let m;
      while ((m = re.exec(h)) && out.length < 8) {
        let u = m[1]; const q = /uddg=([^&]+)/.exec(u); if (q) u = decodeURIComponent(q[1]);
        out.push(`${out.length + 1}. ${html2text(m[2])}\n   ${u}\n   ${html2text(m[3])}`);
      }
      return out.join('\n') || 'No results (the search page layout may have changed).';
    } },
  { name: 'http_request', sig: 'http_request(method, url, headers?, body?)', desc: 'Make an HTTP request (for testing APIs). Non-GET needs approval.',
    danger: (a) => (String(a.method || 'GET').toUpperCase() === 'GET' ? false : `${a.method} ${a.url}`),
    run: async (a) => { const r = await fetch(a.url, { method: a.method || 'GET', headers: a.headers, body: a.body, signal: AbortSignal.timeout(30000) }); return `HTTP ${r.status}\n` + (await r.text()); } },
  { name: 'file_ops', sig: 'file_ops(op, src, dest?)', desc: 'op is mkdir | cp | mv | rm (rm is recursive).',
    danger: (a) => `${a.op} ${a.src}${a.dest ? ' -> ' + a.dest : ''}`,
    run: (a, ctx) => {
      const s = abs(ctx, a.src), d = a.dest ? abs(ctx, a.dest) : null;
      if (a.op === 'mkdir') fs.mkdirSync(s, { recursive: true });
      else if (a.op === 'cp') fs.cpSync(s, d, { recursive: true });
      else if (a.op === 'mv') fs.renameSync(s, d);
      else if (a.op === 'rm') fs.rmSync(s, { recursive: true, force: true });
      else throw new Error('unknown op');
      return `${a.op} ok`;
    } },
  { name: 'project_summary', sig: 'project_summary()', desc: 'Summarize the current project: manifests, file counts by extension, README head.',
    run: (a, ctx) => {
      const ext = {}; let n = 0;
      for (const f of walk(ctx.cwd, 6)) { const e = path.extname(f) || '(none)'; ext[e] = (ext[e] || 0) + 1; if (++n > 5000) break; }
      const mani = ['package.json', 'requirements.txt', 'pyproject.toml', 'Cargo.toml', 'go.mod', 'pom.xml', 'build.gradle', 'Makefile', 'Dockerfile', 'docker-compose.yml', 'tsconfig.json', 'OMNI.md']
        .filter((m) => fs.existsSync(path.join(ctx.cwd, m)));
      const rd = ['README.md', 'readme.md'].map((r) => path.join(ctx.cwd, r)).find(fs.existsSync);
      return `Path: ${ctx.cwd}\nFiles: ${n}\nManifests: ${mani.join(', ') || 'none'}\nExtensions: ${Object.entries(ext).sort((x, y) => y[1] - x[1]).slice(0, 12).map(([k, v]) => k + ':' + v).join(' ')}\n` + (rd ? '\nREADME:\n' + fs.readFileSync(rd, 'utf8').slice(0, 1500) : '');
    } },
  { name: 'todo', sig: 'todo(items:[{text, done}])', desc: 'Set the visible task list for multi-step work; call again to update progress.',
    run: (a, ctx) => {
      const items = (a.items || []).map((i) => (typeof i === 'string' ? { text: i, done: false } : { text: String(i.text), done: !!i.done }));
      ctx.todo.length = 0; ctx.todo.push(...items);
      return items.map((i) => `${i.done ? '☑' : '☐'} ${i.text}`).join('\n') || '(empty)';
    } },
  { name: 'remember', sig: 'remember(text)', desc: 'Save a fact/note to the persistent knowledge base for future sessions.',
    run: (a) => { kb.addText(String(a.text), 'memory:' + Date.now()); return 'Saved to knowledge base'; } },
  { name: 'recall', sig: 'recall(query)', desc: 'Search the knowledge base (notes and added documents).',
    run: (a) => kb.search(String(a.query), 5).map((h) => `[${h.source}]\n${h.text.slice(0, 800)}`).join('\n---\n') || 'Nothing found' },
  { name: 'calc', sig: 'calc(expression)', desc: 'Evaluate a math expression (supports Math.* functions like sqrt, sin, pow, ^).',
    run: (a) => {
      const ex = String(a.expression).replace(/\^/g, '**');
      if (!/^[0-9+\-*/().,%\s a-z_]*$/i.test(ex)) throw new Error('invalid characters');
      for (const id of ex.match(/[a-z_]+/gi) || []) if (!(id in Math)) throw new Error('unknown identifier: ' + id);
      return String(new Function('with(Math){return (' + ex + ')}')());
    } },
  { name: 'sysinfo', sig: 'sysinfo()', desc: 'OS, CPU, memory, Node version, shell, date/time and working directory.',
    run: (a, ctx) => `OS: ${os.type()} ${os.release()} (${os.platform()}/${os.arch()})\nCPU: ${os.cpus().length} cores\nMemory: ${(os.freemem() / 1e9).toFixed(1)} / ${(os.totalmem() / 1e9).toFixed(1)} GB free\nNode: ${process.version}\nShell: ${process.env.SHELL || process.env.ComSpec || 'unknown'}\nUser: ${os.userInfo().username}\nTime: ${new Date().toString()}\nCWD: ${ctx.cwd}` },
  { name: 'json_query', sig: 'json_query(file|text, path?)', desc: 'Read JSON from a file or text and extract a path like "a.b[0].name" (no path = pretty-print; "length" and "keys" work as path ends).',
    run: (a, ctx) => {
      const src = a.file ? fs.readFileSync(abs(ctx, a.file), 'utf8') : String(a.text || '');
      let v = JSON.parse(src);
      for (const k of String(a.path || '').match(/[^.[\]]+/g) || []) {
        if (k === 'length' && v && typeof v.length === 'number') v = v.length;
        else if (k === 'keys' && v && typeof v === 'object') v = Object.keys(v);
        else if (v == null || !(k in Object(v))) throw new Error('path not found at "' + k + '"');
        else v = v[k];
      }
      return JSON.stringify(v, null, 2);
    } },
  { name: 'hash', sig: 'hash(text|file, algo?)', desc: 'Hash text or a file (algo: sha256 default, sha1, sha512, md5).',
    run: (a, ctx) => {
      const algo = String(a.algo || 'sha256').toLowerCase();
      if (!['sha256', 'sha1', 'sha512', 'md5'].includes(algo)) throw new Error('algo must be sha256, sha1, sha512 or md5');
      return algo + ': ' + require('crypto').createHash(algo).update(a.file ? fs.readFileSync(abs(ctx, a.file)) : String(a.text || '')).digest('hex');
    } },
  { name: 'encode', sig: 'encode(op, text?)', desc: 'Quick converters. op: base64 | base64d | url | urld | hex | hexd | uuid | jwt (decode a token, no verification) | timestamp (unix<->ISO; empty = now).',
    run: (a) => {
      const t = String(a.text == null ? '' : a.text), B = Buffer;
      switch (a.op) {
        case 'base64': return B.from(t).toString('base64');
        case 'base64d': return B.from(t, 'base64').toString('utf8');
        case 'url': return encodeURIComponent(t);
        case 'urld': return decodeURIComponent(t);
        case 'hex': return B.from(t).toString('hex');
        case 'hexd': return B.from(t.replace(/\s/g, ''), 'hex').toString('utf8');
        case 'uuid': return require('crypto').randomUUID();
        case 'jwt': {
          const p = t.trim().split('.'); if (p.length < 2) throw new Error('not a JWT');
          const d = (x) => JSON.parse(B.from(x.replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf8'));
          const pay = d(p[1]), when = (n) => (typeof n === 'number' ? new Date(n * 1000).toISOString() : undefined);
          return JSON.stringify({ header: d(p[0]), payload: pay, exp: when(pay.exp), iat: when(pay.iat), note: 'signature NOT verified' }, null, 2);
        }
        case 'timestamp': {
          if (!t.trim()) return `${Math.floor(Date.now() / 1000)}  ${new Date().toISOString()}`;
          const n = Number(t), d = Number.isFinite(n) ? new Date(n < 1e12 ? n * 1000 : n) : new Date(t);
          if (isNaN(d)) throw new Error('cannot parse date');
          return `${Math.floor(d / 1000)}  ${d.toISOString()}  (local: ${d.toString()})`;
        }
        default: throw new Error('op must be base64|base64d|url|urld|hex|hexd|uuid|jwt|timestamp');
      }
    } },
  { name: 'regex_test', sig: 'regex_test(pattern, text, flags?)', desc: 'Test a JavaScript regex against text; lists matches, indexes and capture groups.',
    run: (a) => {
      const re = new RegExp(String(a.pattern), (a.flags || 'g').includes('g') ? a.flags || 'g' : (a.flags || '') + 'g'), out = [];
      for (const m of String(a.text).matchAll(re)) {
        out.push(`#${out.length + 1} @${m.index}: ${JSON.stringify(m[0])}` + (m.length > 1 ? '  groups: ' + JSON.stringify(m.slice(1)) : '') + (m.groups ? '  named: ' + JSON.stringify(m.groups) : ''));
        if (out.length >= 50 || m[0] === '') { if (m[0] === '') break; out.push('…first 50 shown'); break; }
      }
      return out.join('\n') || 'no match';
    } },
  { name: 'ports', sig: 'ports(port?)', desc: 'List TCP ports that are listening (and which process, where the OS allows). Optional port filter.',
    run: async (a, ctx) => {
      const cmd = process.platform === 'win32' ? 'netstat -ano -p TCP' : process.platform === 'darwin' ? 'lsof -iTCP -sTCP:LISTEN -nP' : 'ss -ltnp 2>/dev/null || netstat -ltnp 2>/dev/null';
      let out = await run(cmd, ctx, 15);
      if (process.platform === 'linux' && /exit code: (127|[1-9])/.test(out.split('\n')[0])) {   // no ss/netstat: read the kernel table
        const rows = [];
        for (const f of ['/proc/net/tcp', '/proc/net/tcp6']) {
          try { for (const l of fs.readFileSync(f, 'utf8').split('\n').slice(1)) { const c = l.trim().split(/\s+/); if (c[3] === '0A') rows.push('LISTEN  ' + parseInt(c[1].split(':')[1], 16)); } } catch { /* none */ }
        }
        out = 'exit code: 0\nState   Port\n' + [...new Set(rows)].sort((x, y) => Number(x.slice(8)) - Number(y.slice(8))).join('\n');
      }
      if (process.platform === 'win32') out = out.split('\n').filter((l) => /LISTENING|exit code|Proto/.test(l)).join('\n');
      if (a.port) out = out.split('\n').filter((l, i) => i < 2 || new RegExp('([:.]|\\s)' + String(a.port).replace(/\D/g, '') + '(\\s|$)').test(l)).join('\n');
      return out;
    } },
  { name: 'deps', sig: 'deps()', desc: 'List the project dependencies from package.json, requirements.txt, go.mod, Cargo.toml, pyproject.toml or composer.json.',
    run: (a, ctx) => {
      const out = [], rd = (f) => { try { return fs.readFileSync(path.join(ctx.cwd, f), 'utf8'); } catch { return null; } };
      let s = rd('package.json');
      if (s) { try { const j = JSON.parse(s); for (const k of ['dependencies', 'devDependencies', 'peerDependencies']) if (j[k]) out.push(`# package.json ${k}\n` + Object.entries(j[k]).map(([n, v]) => `${n}  ${v}`).join('\n')); } catch { out.push('package.json: invalid JSON'); } }
      s = rd('requirements.txt'); if (s) out.push('# requirements.txt\n' + s.split('\n').filter((l) => l.trim() && !l.startsWith('#')).join('\n'));
      s = rd('go.mod'); if (s) out.push('# go.mod\n' + (s.match(/^\s*(?:require\s+)?[\w.\-/]+\.[\w.\-/]+\s+v[\w.\-+]+/gm) || []).map((l) => l.trim().replace(/^require\s+/, '')).join('\n'));
      s = rd('Cargo.toml'); if (s) out.push('# Cargo.toml\n' + (s.split(/^\[(?=[\w.-]*dependencies)/m).slice(1).map((b) => '[' + b.trim()).join('\n')));
      s = rd('pyproject.toml'); if (s) { const m = s.match(/dependencies\s*=\s*\[([\s\S]*?)\]/); if (m) out.push('# pyproject.toml\n' + m[1].replace(/[\s"',]+/g, ' ').trim().split(' ').join('\n')); }
      s = rd('composer.json'); if (s) { try { const j = JSON.parse(s); out.push('# composer.json\n' + Object.entries({ ...j.require, ...j['require-dev'] }).map(([n, v]) => `${n}  ${v}`).join('\n')); } catch { /* ignore */ } }
      return out.join('\n\n') || 'No dependency manifest found';
    } },
  { name: 'lint', sig: 'lint(command?)', desc: 'Run the project linter (auto-detects npm lint/eslint/ruff/flake8/clippy/go vet) and return output.',
    danger: (a) => `run lint: ${a.command || '(auto-detected)'}`,
    run: (a, ctx) => { const c = a.command || lintCommand(ctx.cwd); if (!c) throw new Error('No linter detected; pass command'); return run(c, ctx, 300).then((r) => `$ ${c}\n${r}`); } },
  { name: 'build', sig: 'build(command?)', desc: 'Build the project (auto-detects npm build, cargo, go, maven, gradle, make) and return output.',
    danger: (a) => `run build: ${a.command || '(auto-detected)'}`,
    run: (a, ctx) => { const c = a.command || buildCommand(ctx.cwd); if (!c) throw new Error('No build command detected; pass command'); return run(c, ctx, 600).then((r) => `$ ${c}\n${r}`); } },
  { name: 'loc', sig: 'loc(path?)', desc: 'Count files and lines of code by language for the project (or a sub-path).',
    run: (a, ctx) => {
      const L = { js: 'JavaScript', mjs: 'JavaScript', cjs: 'JavaScript', jsx: 'JavaScript', ts: 'TypeScript', tsx: 'TypeScript', py: 'Python', rs: 'Rust', go: 'Go', java: 'Java', kt: 'Kotlin', c: 'C', h: 'C/C++ header', cpp: 'C++', cc: 'C++', cs: 'C#', rb: 'Ruby', php: 'PHP', swift: 'Swift', sh: 'Shell', ps1: 'PowerShell', bat: 'Batch', html: 'HTML', css: 'CSS', scss: 'SCSS', vue: 'Vue', svelte: 'Svelte', json: 'JSON', md: 'Markdown', yml: 'YAML', yaml: 'YAML', toml: 'TOML', sql: 'SQL', lua: 'Lua', dart: 'Dart', ex: 'Elixir', zig: 'Zig' };
      const st = {}; let n = 0;
      for (const f of walk(abs(ctx, a.path), 12)) {
        const lang = L[path.extname(f).slice(1).toLowerCase()]; if (!lang || ++n > 20000) continue;
        let t; try { if (fs.statSync(f).size > 2e6) continue; t = fs.readFileSync(f, 'utf8'); } catch { continue; }
        const ls = t.split('\n'), x = st[lang] || (st[lang] = { files: 0, lines: 0, code: 0 });
        x.files++; x.lines += ls.length; x.code += ls.filter((l) => l.trim()).length;
      }
      const rows = Object.entries(st).sort((p, q) => q[1].code - p[1].code);
      if (!rows.length) return 'No source files found';
      const tot = rows.reduce((s, [, v]) => ({ files: s.files + v.files, lines: s.lines + v.lines, code: s.code + v.code }), { files: 0, lines: 0, code: 0 });
      const fmt = (k, v) => `${k.padEnd(14)} ${String(v.files).padStart(6)} ${String(v.lines).padStart(8)} ${String(v.code).padStart(8)}`;
      return ['Language        files    lines     code', ...rows.map(([k, v]) => fmt(k, v)), fmt('TOTAL', tot)].join('\n');
    } },
  { name: 'scan_todos', sig: 'scan_todos(path?)', desc: 'Find TODO / FIXME / HACK / XXX / BUG comments across the project with file:line.',
    run: (a, ctx) => {
      const out = [], re = /\b(TODO|FIXME|HACK|XXX|BUG)\b[:( ]*(.*)/;
      for (const f of walk(abs(ctx, a.path), 12)) {
        if (out.length >= 200) { out.push('…first 200 shown'); break; }
        try { if (fs.statSync(f).size > 500000 || isBinary(f)) continue; } catch { continue; }
        fs.readFileSync(f, 'utf8').split('\n').forEach((l, i) => { const m = re.exec(l); if (m && out.length < 200) out.push(`${rel(ctx, f)}:${i + 1}  ${m[1]} ${m[2].trim().slice(0, 100)}`); });
      }
      return out.join('\n') || 'No TODO/FIXME comments found';
    } },
  { name: 'scan_secrets', sig: 'scan_secrets(path?)', desc: 'Scan the project for likely leaked secrets (API keys, tokens, private keys, passwords). Values are masked in the output.',
    run: (a, ctx) => {
      const pats = [['AWS access key', /AKIA[0-9A-Z]{16}/], ['private key', /-----BEGIN (?:RSA |EC |OPENSSH |DSA |PGP )?PRIVATE KEY-----/], ['GitHub token', /gh[pousr]_[A-Za-z0-9]{36,}/],
        ['Slack token', /xox[baprs]-[A-Za-z0-9-]{10,}/], ['Google API key', /AIza[0-9A-Za-z_-]{35}/], ['Anthropic key', /sk-ant-[A-Za-z0-9_-]{20,}/], ['OpenAI-style key', /sk-[A-Za-z0-9]{32,}/],
        ['hard-coded credential', /(?:api[_-]?key|secret|token|passwd|password)\s*[:=]\s*['"][^'"\s]{8,}['"]/i]];
      const out = [];
      for (const f of walk(abs(ctx, a.path), 12)) {
        if (/(package-lock\.json|yarn\.lock|pnpm-lock\.yaml|\.min\.js)$/.test(f)) continue;
        try { if (fs.statSync(f).size > 500000 || isBinary(f)) continue; } catch { continue; }
        fs.readFileSync(f, 'utf8').split('\n').forEach((l, i) => {
          for (const [name, re] of pats) { const m = re.exec(l); if (m && out.length < 100) { out.push(`${rel(ctx, f)}:${i + 1}  ${name}: ${m[0].slice(0, 6)}…(masked)`); break; } }
        });
      }
      return out.length ? `${out.length} possible secret(s) — review each; rotate anything real:\n` + out.join('\n') : 'No obvious secrets found';
    } },
  { name: 'diff_files', sig: 'diff_files(a, b)', desc: 'Show a unified diff between two files or folders.',
    run: (a, ctx) => run(`git diff --no-index --no-color -- ${JSON.stringify(abs(ctx, a.a))} ${JSON.stringify(abs(ctx, a.b))}`, ctx, 30).then((r) => r.replace(/^exit code: [01]\n/, '') || 'identical') },
  { name: 'ask_user', sig: 'ask_user(question)', desc: 'Ask the user a clarifying question and wait for the answer.',
    run: async (a, ctx) => (await ctx.ask(`  ${a.question}\n  › `)).trim() || '(no answer)' },
];

const get = (n) => TOOLS.find((t) => t.name === n);
async function exec_(tool, args, ctx) {
  try { const r = await tool.run(args || {}, ctx); return cap(String(r === undefined || r === '' ? '(no output)' : r)); }
  catch (e) { return 'Error: ' + (e.message || e); }
}

function protocol() {
  return `## Agent mode
You can act on the user's computer with tools. To call a tool, output exactly:
<tool>{"name":"TOOL_NAME","args":{...}}</tool>
Rules:
- You may emit several <tool> blocks in one reply. After emitting tool calls, STOP and wait; results arrive in the next message inside <tool_result> tags. Never invent results.
- Arguments must be valid JSON (escape newlines in strings as \\n).
- Read before you edit. Prefer edit_file for small changes. Verify your work by running tests/commands when possible.
- For multi-step tasks, use the todo tool to plan and track progress.
- When the task is complete, answer normally with NO <tool> block.
Tools:
${TOOLS.map((t) => `- ${t.sig} — ${t.desc}`).join('\n')}`;
}

module.exports = { TOOLS, get, exec: exec_, protocol, testCommand, lintCommand, buildCommand };
