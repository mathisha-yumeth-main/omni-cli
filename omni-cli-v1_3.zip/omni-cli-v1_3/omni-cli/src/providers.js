'use strict';
const { getKey } = require('./config');
const { makeSplitter } = require('./ui');

const PROVIDERS = {
  ollama: { label: 'Ollama' }, claude: { label: 'Claude' }, gemini: { label: 'Gemini' },
  openai: { label: 'OpenAI' }, xai: { label: 'xAI (Grok)' },
};
const ALIASES = { anthropic: 'claude', google: 'gemini', grok: 'xai', gpt: 'openai', chatgpt: 'openai', local: 'ollama' };

const CLAUDE_BUDGET = { low: 0, medium: 4000, high: 12000, max: 30000 };
const GEMINI_BUDGET = { low: 512, medium: 4096, high: 12000, max: 24576 };

async function* lines(res) {
  const reader = res.body.getReader(), dec = new TextDecoder();
  let buf = '';
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    let i;
    while ((i = buf.indexOf('\n')) >= 0) { yield buf.slice(0, i).replace(/\r$/, ''); buf = buf.slice(i + 1); }
  }
  if (buf) yield buf;
}

function errMsg(name, status, text) {
  let m = text;
  try { const j = JSON.parse(text); m = (j.error && (j.error.message || j.error)) || j.message || text; } catch { /* raw */ }
  return `${name} API ${status}: ${typeof m === 'string' ? m : JSON.stringify(m)}`.slice(0, 600);
}

const post = (url, headers, body, signal) =>
  fetch(url, { method: 'POST', headers: { 'content-type': 'application/json', ...headers }, body: JSON.stringify(body), signal });

// POST with one automatic retry if the API rejects an optional feature (thinking, reasoning_effort...).
async function send(name, url, headers, body, signal, fix) {
  let res = await post(url, headers, body, signal);
  if (res.ok) return res;
  const t = await res.text().catch(() => '');
  if (fix && fix.re.test(t)) {
    fix.apply(body);
    res = await post(url, headers, body, signal);
    if (res.ok) return res;
    throw new Error(errMsg(name, res.status, await res.text().catch(() => '')));
  }
  throw new Error(errMsg(name, res.status, t));
}

const offline = (cfg) => new Error(`Cannot reach Ollama at ${hostOf(cfg)}. Start it (open the Ollama app, or run: ollama serve) and try again. Different host? /host <url>`);

function need(cfg, p) {
  const k = getKey(cfg, p);
  if (!k) throw new Error(`No API key for ${PROVIDERS[p].label}. Run:  /key ${p} <your-key>   (or set the environment variable)`);
  return k;
}

const hostOf = (cfg) => {
  let h = process.env.OLLAMA_HOST || cfg.hosts.ollama;
  if (!/^https?:\/\//.test(h)) h = 'http://' + h;
  // Node on Windows resolves "localhost" to IPv6 (::1) but Ollama listens on IPv4 only -> "fetch failed"
  return h.replace(/\/$/, '').replace(/^(https?:\/\/)localhost(?=[:/]|$)/i, '$1127.0.0.1');
};

async function claude(cfg, { messages, system, signal, onText, onThink }) {
  const key = need(cfg, 'claude'), budget = CLAUDE_BUDGET[cfg.effort] || 0;
  const body = { model: cfg.models.claude, max_tokens: budget + 8192, stream: true, system, messages };
  if (budget) body.thinking = { type: 'enabled', budget_tokens: budget };
  const res = await send('Claude', 'https://api.anthropic.com/v1/messages',
    { 'x-api-key': key, 'anthropic-version': '2023-06-01' }, body, signal,
    { re: /thinking|budget/i, apply: (b) => { delete b.thinking; b.max_tokens = 8192; } });
  let text = ''; const usage = { in: 0, out: 0 };
  for await (const l of lines(res)) {
    if (!l.startsWith('data:')) continue;
    let j; try { j = JSON.parse(l.slice(5)); } catch { continue; }
    if (j.type === 'content_block_delta') {
      const d = j.delta;
      if (d.type === 'text_delta') { text += d.text; onText(d.text); }
      else if (d.type === 'thinking_delta') onThink(d.thinking);
    } else if (j.type === 'message_start') usage.in = (j.message.usage && j.message.usage.input_tokens) || 0;
    else if (j.type === 'message_delta') usage.out = (j.usage && j.usage.output_tokens) || usage.out;
    else if (j.type === 'error') throw new Error('Claude: ' + ((j.error && j.error.message) || 'stream error'));
  }
  return { text, usage };
}

// OpenAI and xAI share the chat-completions wire format.
async function oai(cfg, pid, { messages, system, signal, onText, onThink }) {
  const key = need(cfg, pid), model = cfg.models[pid];
  const base = pid === 'xai' ? 'https://api.x.ai/v1' : 'https://api.openai.com/v1';
  const body = { model, stream: true, stream_options: { include_usage: true },
    messages: [{ role: 'system', content: system }, ...messages] };
  if (pid === 'openai' && /^(o\d|gpt-5)/.test(model)) body.reasoning_effort = cfg.effort === 'max' ? 'high' : cfg.effort;
  if (pid === 'xai' && /mini/.test(model)) body.reasoning_effort = cfg.effort === 'low' || cfg.effort === 'medium' ? 'low' : 'high';
  const res = await send(PROVIDERS[pid].label, base + '/chat/completions', { authorization: 'Bearer ' + key }, body, signal,
    { re: /reasoning_effort|stream_options/i, apply: (b) => { delete b.reasoning_effort; delete b.stream_options; } });
  let text = ''; const usage = { in: 0, out: 0 };
  for await (const l of lines(res)) {
    if (!l.startsWith('data:')) continue;
    const d = l.slice(5).trim();
    if (!d || d === '[DONE]') continue;
    let j; try { j = JSON.parse(d); } catch { continue; }
    const dl = j.choices && j.choices[0] && j.choices[0].delta;
    if (dl) {
      const th = dl.reasoning_content || dl.reasoning;
      if (th) onThink(th);
      if (dl.content) { text += dl.content; onText(dl.content); }
    }
    if (j.usage) { usage.in = j.usage.prompt_tokens || 0; usage.out = j.usage.completion_tokens || 0; }
  }
  return { text, usage };
}

async function gemini(cfg, { messages, system, signal, onText, onThink }) {
  const key = need(cfg, 'gemini'), model = cfg.models.gemini;
  const body = {
    systemInstruction: { parts: [{ text: system }] },
    contents: messages.map((m) => ({ role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: m.content }] })),
    generationConfig: { thinkingConfig: { thinkingBudget: GEMINI_BUDGET[cfg.effort], includeThoughts: true } },
  };
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:streamGenerateContent?alt=sse`;
  const res = await send('Gemini', url, { 'x-goog-api-key': key }, body, signal,
    { re: /thinking/i, apply: (b) => { delete b.generationConfig; } });
  let text = ''; const usage = { in: 0, out: 0 };
  for await (const l of lines(res)) {
    if (!l.startsWith('data:')) continue;
    let j; try { j = JSON.parse(l.slice(5)); } catch { continue; }
    const parts = (j.candidates && j.candidates[0] && j.candidates[0].content && j.candidates[0].content.parts) || [];
    for (const p of parts) {
      if (!p.text) continue;
      if (p.thought) onThink(p.text); else { text += p.text; onText(p.text); }
    }
    if (j.usageMetadata) { usage.in = j.usageMetadata.promptTokenCount || 0; usage.out = j.usageMetadata.candidatesTokenCount || 0; }
  }
  return { text, usage };
}

// ---- Ollama: per-model capability detection (/api/show) so every installed model is handled correctly ----
const REASONING_RE = /(qwen3|deepseek-r1|gpt-oss|magistral|reasoning|qwq|cogito|r1|thinking)/i; // fallback for old Ollama without capabilities
const showCache = {};
async function ollamaShow(cfg, model) {
  const key = hostOf(cfg) + '|' + model;
  if (showCache[key]) return showCache[key];
  try {
    const r = await fetch(hostOf(cfg) + '/api/show', { method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ model }), signal: AbortSignal.timeout(8000) });
    if (!r.ok) return { caps: null, ctxMax: 0 };
    const j = await r.json(), mi = j.model_info || {}, ck = Object.keys(mi).find((k) => /\.context_length$/.test(k));
    return (showCache[key] = { caps: Array.isArray(j.capabilities) ? j.capabilities : null, ctxMax: ck ? Number(mi[ck]) || 0 : 0 });
  } catch { return { caps: null, ctxMax: 0 }; }
}
const isEmbedOnly = (caps) => !!caps && caps.includes('embedding') && !caps.includes('completion');

async function ollama(cfg, { messages, system, signal, onText, onThink }) {
  const host = hostOf(cfg), model = cfg.models.ollama;
  const info = await ollamaShow(cfg, model);
  if (isEmbedOnly(info.caps)) throw new Error(`"${model}" is an embedding model and cannot chat. Pick another with /model (see /models).`);
  const want = cfg.numCtx || 8192, numCtx = info.ctxMax ? Math.min(want, info.ctxMax) : want;   // never ask for more than the model supports
  const body = { model, stream: true, options: { num_ctx: numCtx },
    messages: [{ role: 'system', content: system }, ...messages] };
  const canThink = info.caps ? info.caps.includes('thinking') : REASONING_RE.test(model);   // only send `think` to models that support it
  if (canThink) body.think = /gpt-oss/i.test(model) ? (cfg.effort === 'max' ? 'high' : cfg.effort) : cfg.effort !== 'low';
  let res;
  try {
    res = await send('Ollama', host + '/api/chat', {}, body, signal, { re: /think/i, apply: (b) => { delete b.think; } });
  } catch (e) {
    if (e.name !== 'AbortError' && /fetch failed/i.test(e.message)) {
      throw new Error(`Cannot reach Ollama at ${host}. Is it running? (try: ollama serve)  Change host with /host <url>`);
    }
    throw e;
  }
  let text = ''; const usage = { in: 0, out: 0, numCtx };
  const split = makeSplitter('<think>', '</think>', (s) => { text += s; onText(s); }, onThink); // older reasoning models
  for await (const l of lines(res)) {
    if (!l.trim()) continue;
    let j; try { j = JSON.parse(l); } catch { continue; }
    if (j.error) throw new Error('Ollama: ' + j.error);
    if (j.message) {
      if (j.message.thinking) onThink(j.message.thinking);
      if (j.message.content) split.push(j.message.content);
    }
    if (j.done) { usage.in = j.prompt_eval_count || 0; usage.out = j.eval_count || 0; }
  }
  split.flush();
  return { text, usage };
}

function chat(cfg, args) {
  switch (cfg.provider) {
    case 'claude': return claude(cfg, args);
    case 'gemini': return gemini(cfg, args);
    case 'openai': return oai(cfg, 'openai', args);
    case 'xai': return oai(cfg, 'xai', args);
    default: return ollama(cfg, args);
  }
}

async function listModels(cfg, p) {
  const get = async (url, headers) => {
    const r = await fetch(url, { headers, signal: AbortSignal.timeout(8000) });
    if (!r.ok) throw new Error(`${r.status} ${(await r.text()).slice(0, 200)}`);
    return r.json();
  };
  if (p === 'ollama') return ((await get(hostOf(cfg) + '/api/tags').catch((e) => { throw /fetch failed|abort|timeout/i.test(e.message) ? offline(cfg) : e; })).models || []).map((m) => m.name);
  const key = getKey(cfg, p);
  if (!key) throw new Error('no API key set (use /key)');
  if (p === 'claude') return (await get('https://api.anthropic.com/v1/models?limit=100', { 'x-api-key': key, 'anthropic-version': '2023-06-01' })).data.map((m) => m.id);
  if (p === 'gemini') {
    const j = await get('https://generativelanguage.googleapis.com/v1beta/models?pageSize=200', { 'x-goog-api-key': key });
    return j.models.filter((m) => (m.supportedGenerationMethods || []).includes('generateContent')).map((m) => m.name.replace('models/', ''));
  }
  const base = p === 'xai' ? 'https://api.x.ai/v1' : 'https://api.openai.com/v1';
  let ids = (await get(base + '/models', { authorization: 'Bearer ' + key })).data.map((m) => m.id).sort();
  if (p === 'openai') ids = ids.filter((i) => /^(gpt|o\d|chatgpt)/.test(i) && !/(embed|tts|whisper|dall|image|audio|realtime|transcribe|moderation)/.test(i));
  return ids;
}


// Like listModels, but with extra detail where the provider offers it (Ollama: size, parameters, quantization).
async function modelInfo(cfg, p) {
  if (p === 'ollama') {
    const r = await fetch(hostOf(cfg) + '/api/tags', { signal: AbortSignal.timeout(8000) }).catch(() => { throw offline(cfg); });
    if (!r.ok) throw new Error(`${r.status} ${(await r.text()).slice(0, 200)}`);
    const rows = ((await r.json()).models || []).map((m) => ({ id: m.name, size: m.size, params: m.details && m.details.parameter_size, quant: m.details && m.details.quantization_level }));
    await Promise.all(rows.map(async (m) => { const i = await ollamaShow(cfg, m.id); m.caps = i.caps; m.ctxMax = i.ctxMax; }));
    return rows;
  }
  return (await listModels(cfg, p)).map((id) => ({ id }));
}

// Installed Ollama models that can actually chat (embedding-only models are left out).
async function chatModels(cfg) { return (await modelInfo(cfg, 'ollama')).filter((m) => !isEmbedOnly(m.caps)); }

// Short names people actually type. Anything else is fuzzy-matched against the provider's live model list.
const MODEL_ALIASES = {
  claude: { sonnet: 'claude-sonnet-5-5', opus: 'claude-opus-5-5', haiku: 'claude-haiku-5-5', fable: 'claude-fable-5-2', fast: 'claude-haiku-5-5', best: 'claude-opus-5-5', smart: 'claude-sonnet-5-5' },
};
const modelCache = {};
async function resolveModel(cfg, p, input) {
  const q = String(input || '').trim();
  if (!q) return q;
  const al = (MODEL_ALIASES[p] || {})[q.toLowerCase()];
  if (al) return al;
  let list = modelCache[p] && Date.now() - modelCache[p].t < 300000 ? modelCache[p].ids : null;
  if (!list) { try { list = p === 'ollama' ? (await chatModels(cfg)).map((m) => m.id) : await listModels(cfg, p); modelCache[p] = { t: Date.now(), ids: list }; } catch { return q; } }
  const lc = q.toLowerCase();
  if (list.includes(q)) return q;
  if (p === 'ollama' && list.includes(q + ':latest')) return q + ':latest';
  const hits = list.filter((m) => m.toLowerCase().includes(lc));
  if (!hits.length) return q;
  // prefer names that start with the query, then the shortest (usually the plain/latest alias), then reverse-alphabetical (newer versions sort later)
  hits.sort((a, b) => (b.toLowerCase().startsWith(lc) - a.toLowerCase().startsWith(lc)) || a.length - b.length || (a < b ? 1 : -1));
  return hits[0];
}

module.exports = { PROVIDERS, ALIASES, MODEL_ALIASES, chat, listModels, hostOf, resolveModel, modelInfo, chatModels };
