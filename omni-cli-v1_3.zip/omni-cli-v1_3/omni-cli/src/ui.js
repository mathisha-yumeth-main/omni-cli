'use strict';
const COLOR = !process.env.NO_COLOR && (process.stdout.isTTY || process.env.FORCE_COLOR);
const wrap = (o, c) => (s) => (COLOR ? `\x1b[${o}m${s}\x1b[${c}m` : String(s));

const ui = {
  bold: wrap(1, 22), dim: wrap(2, 22), italic: wrap(3, 23),
  red: wrap(31, 39), green: wrap(32, 39), yellow: wrap(33, 39), cyan: wrap(36, 39), gray: wrap(90, 39),
};
ui.rgb = (c, s) => (COLOR ? `\x1b[38;2;${c[0]};${c[1]};${c[2]}m${s}\x1b[39m` : String(s));

const strip = (s) => String(s).replace(/\x1b\[[0-9;]*m/g, '');
const vlen = (s) => [...strip(s)].length;
const pad = (s, w) => s + ' '.repeat(Math.max(0, w - vlen(s)));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const trunc = (s, n) => (s.length > n ? s.slice(0, n - 1) + '…' : s);
const truncTail = (s, n) => (s.length > n ? '…' + s.slice(-(n - 1)) : s);

// Pixel-art renderer: two pixel rows per text row using half blocks (▀ ▄ █) and truecolor.
// grid = array of equal-width strings, pal maps a character to [r,g,b] ('.' = transparent).
function pixels(grid, pal) {
  const fg = (c) => `\x1b[38;2;${c[0]};${c[1]};${c[2]}m`, bg = (c) => `\x1b[48;2;${c[0]};${c[1]};${c[2]}m`, off = '\x1b[0m';
  const rows = [];
  for (let y = 0; y < grid.length; y += 2) {
    const a = grid[y], b = grid[y + 1] || '';
    let line = '';
    for (let x = 0; x < a.length; x++) {
      const t = pal[a[x]], u = pal[b[x]];
      if (!COLOR) line += t || u ? '█' : ' ';
      else if (!t && !u) line += ' ';
      else if (t && !u) line += fg(t) + '▀' + off;
      else if (!t && u) line += fg(u) + '▄' + off;
      else if (t[0] === u[0] && t[1] === u[1] && t[2] === u[2]) line += fg(t) + '█' + off;
      else line += fg(t) + bg(u) + '▀' + off;
    }
    rows.push(line);
  }
  return rows;
}

// The Ollama llama: long ears, round head, cream muzzle with nose and smile. 16x18 pixels -> 16x9 characters.
const LLAMA = pixels([
  '...##......##...',
  '...##......##...',
  '..###......###..',
  '..###......###..',
  '..############..',
  '.##############.',
  '.##############.',
  '.##EE######EE##.',
  '.##EE######EE##.',
  '.##############.',
  '..##uuuuuuuu##..',
  '..#uuuuuuuuuu#..',
  '..#uuuNNNNuuu#..',
  '..#uuuuNNuuuu#..',
  '..#uuMuuuuMuu#..',
  '...#uuMMMMuu#...',
  '....##uuuu##....',
  '......####......',
], { '#': [240, 240, 244], u: [255, 226, 196], E: [30, 30, 38], N: [48, 40, 44], M: [48, 40, 44] });

// Each provider has its own colour and mascot, shown when you switch provider.
const BRAND = {
  claude: { label: 'Claude', rgb: [217, 119, 87], art: ['  ▗▄██▄▖  ', ' ▟██████▙ ', '  ▀▘  ▝▀  '] },
  ollama: { label: 'Ollama', rgb: [235, 235, 235], raw: true, art: LLAMA },
  gemini: { label: 'Gemini', rgb: [100, 150, 255], art: ['    ▟▙    ', '  ▟████▙  ', '    ▜▛    '] },
  openai: { label: 'OpenAI', rgb: [16, 185, 140], art: ['  ▟████▙  ', ' ▐██▙▟██▌ ', '  ▜████▛  '] },
  xai: { label: 'xAI Grok', rgb: [200, 200, 215], art: [' ▜▙    ▟▛ ', '   ▜██▛   ', ' ▟▛    ▜▙ '] },
};

function welcome(info) {
  const b = BRAND[info.provider];
  const col = (s) => ui.rgb(b.rgb, s);
  const W = Math.max(72, Math.min(process.stdout.columns || 100, 104));
  const inner = W - 2, lw = 34, rw = inner - lw - 1;
  const center = (s, w) => ' '.repeat(Math.max(0, Math.floor((w - vlen(s)) / 2))) + s;
  const left = [
    '', center(ui.bold('Welcome to Omni CLI'), lw), '',
    ...b.art.map((a) => center(b.raw ? a : col(a), lw)), '',
    center(ui.bold(col(b.label)), lw),
    center(ui.dim(trunc(info.model, lw - 2)), lw),
    center(ui.dim(truncTail(info.cwd, lw - 2)), lw),
  ];
  const dev = [];
  if (info.git) dev.push(`${col('branch')} ${info.git.branch}${info.git.dirty ? ui.yellow(' ●' + info.git.dirty) : ui.green(' ✓')}`);
  if (info.stack) dev.push(ui.dim('stack ') + info.stack);
  const right = [
    ui.bold(col('Getting started')),
    '/help       all commands',
    '/provider   switch (claude:opus works)',
    '/model      pick or alias a model',
    '/agent      tools & autonomy',
    '/review     review your git diff',
    '/commit     AI commit message',
    '/test       run tests, fix failures',
    '/skills     browse ' + info.nskills + ' skills',
    '',
    ui.bold(col('Status')),
    `effort ${info.effort} · agent ${info.agent ? 'on' : 'off'}${info.plan ? ' · plan' : ''}`,
    `${info.nskills} skills ${info.auto ? ui.green('auto-routed') : ui.dim('(auto off)')}${info.skills ? ' · ' + info.skills + ' pinned' : ''}`,
    ...dev,
  ];
  const t = `─── Omni CLI v${info.version} `;
  const out = [col('╭' + t + '─'.repeat(inner - vlen(t)) + '╮')];
  const rows = Math.max(left.length, right.length);
  for (let i = 0; i < rows; i++) {
    out.push(col('│') + pad(left[i] || '', lw) + col('│') + ' ' + pad(right[i] || '', rw - 1) + col('│'));
  }
  out.push(col('╰' + '─'.repeat(inner) + '╯'));
  return out;
}

const VERBS = ['Thinking', 'Pondering', 'Cogitating', 'Ruminating', 'Synthesizing', 'Percolating',
  'Mulling', 'Noodling', 'Deliberating', 'Conjuring', 'Reasoning', 'Untangling', 'Brewing', 'Scheming'];
const FRAMES = ['·', '✢', '✳', '✶', '✻', '✽', '✻', '✶', '✳', '✢'];

// Animated "thinking" indicator: rotating glyph, shimmering verb, timer, token counter.
class Spinner {
  constructor(rgb) { this.c = rgb; this.t = null; this.tokens = 0; }
  begin() {
    if (!process.stdout.isTTY) return;
    this.start = Date.now(); this.tokens = 0;
    this.v0 = Math.floor(Math.random() * VERBS.length);
    process.stdout.write('\x1b[?25l');
    this.t = setInterval(() => this.draw(), 80);
    this.draw();
  }
  draw() {
    const el = Date.now() - this.start, sec = Math.floor(el / 1000);
    const verb = VERBS[(this.v0 + Math.floor(el / 3500)) % VERBS.length];
    const frame = FRAMES[Math.floor(el / 100) % FRAMES.length];
    let s = '';
    [...verb + '…'].forEach((ch, i) => {
      const k = 0.5 + 0.5 * Math.sin(el / 180 - i * 0.6);
      const m = (v) => Math.round(v + (255 - v) * k * 0.65);
      s += ui.rgb([m(this.c[0]), m(this.c[1]), m(this.c[2])], ch);
    });
    const info = ui.dim(`(${sec}s · ↓ ${Math.round(this.tokens)} tokens · ctrl+c to interrupt)`);
    process.stdout.write(`\r\x1b[2K${ui.rgb(this.c, frame)} ${s} ${info}`);
  }
  stop() {
    if (!this.t) return;
    clearInterval(this.t); this.t = null;
    process.stdout.write('\r\x1b[2K\x1b[?25h');
  }
}

// Streaming Markdown-lite renderer: styles code fences, headings, **bold** and `inline code` line by line.
// Code lines are left unmodified apart from colour, so copy/paste from the terminal still works.
function makeMd(rgb) {
  let buf = '', fence = false;
  const line = (l) => {
    if (!COLOR) return l;
    const f = /^\s*(```|~~~)\s*([\w+#.-]*)/.exec(l);
    if (f) { fence = !fence; return ui.dim(fence ? '╭─ ' + (f[2] || 'code') : '╰─'); }
    if (fence) return ui.rgb([160, 205, 180], l);
    const h = /^(#{1,6})\s+(.*)$/.exec(l);
    if (h) return ui.bold(ui.rgb(rgb, h[2]));
    return l.replace(/`([^`\n]+)`/g, (x, c) => ui.rgb([240, 200, 120], c)).replace(/\*\*([^*\n]+)\*\*/g, (x, c) => ui.bold(c));
  };
  return {
    push(chunk) {
      buf += chunk;
      const i = buf.lastIndexOf('\n');
      if (i < 0) return '';
      const done = buf.slice(0, i).split('\n').map(line).join('\n') + '\n';
      buf = buf.slice(i + 1);
      return done;
    },
    flush() { const r = buf ? line(buf) : ''; buf = ''; fence = false; return r; },
  };
}

// Splits a text stream on <open>…</open> even when tags are cut across chunks.
function makeSplitter(open, close, onOut, onIn) {
  let inside = false, buf = '';
  const hold = (s, tag) => {
    for (let n = Math.min(tag.length - 1, s.length); n > 0; n--) if (tag.startsWith(s.slice(-n))) return n;
    return 0;
  };
  return {
    push(chunk) {
      buf += chunk;
      for (;;) {
        const tag = inside ? close : open, i = buf.indexOf(tag);
        if (i >= 0) {
          (inside ? onIn : onOut)(buf.slice(0, i));
          buf = buf.slice(i + tag.length); inside = !inside; continue;
        }
        const h = hold(buf, tag), emit = buf.slice(0, buf.length - h);
        if (emit) (inside ? onIn : onOut)(emit);
        buf = buf.slice(buf.length - h);
        break;
      }
    },
    flush() { if (buf) { (inside ? onIn : onOut)(buf); buf = ''; } },
  };
}

module.exports = { ui, BRAND, welcome, Spinner, makeSplitter, makeMd, pixels, vlen, strip, sleep, trunc };
