'use strict';
const fs = require('fs'), os = require('os'), path = require('path');

const DIR = process.env.OMNI_HOME || path.join(os.homedir(), '.omni');
const FILE = path.join(DIR, 'config.json');

const defaults = {
  provider: 'ollama',
  models: { ollama: 'llama3.2', claude: 'claude-sonnet-5-5', gemini: 'gemini-2.5-pro', openai: 'gpt-5', xai: 'grok-4' },
  keys: {},
  hosts: { ollama: 'http://127.0.0.1:11434' },
  effort: 'medium',      // low | medium | high | max
  agent: false,
  autoApprove: false,
  thinkingView: true,
  numCtx: 8192,          // Ollama context window
  maxSteps: 25,          // max agent steps per request
  skillsAuto: true,      // route every message to the most relevant skills automatically
  skillsMax: 4,          // how many skills the router may inject per message
  macros: {},            // user-defined slash commands (/macro)
  plan: false,           // plan mode: model may read but not write/execute
};

const ENV = { claude: 'ANTHROPIC_API_KEY', gemini: 'GEMINI_API_KEY', openai: 'OPENAI_API_KEY', xai: 'XAI_API_KEY' };

function ensure() { fs.mkdirSync(DIR, { recursive: true }); }

function load() {
  ensure();
  let c = {};
  try { c = JSON.parse(fs.readFileSync(FILE, 'utf8')); } catch { /* first run */ }
  return {
    ...defaults, ...c,
    models: { ...defaults.models, ...c.models },
    keys: { ...c.keys },
    hosts: { ...defaults.hosts, ...c.hosts },
  };
}

function save(c) {
  ensure();
  fs.writeFileSync(FILE, JSON.stringify(c, null, 2));
  try { fs.chmodSync(FILE, 0o600); } catch { /* windows */ }
}

function getKey(c, p) {
  return c.keys[p] || process.env[ENV[p]] || (p === 'gemini' ? process.env.GOOGLE_API_KEY : '') || '';
}

module.exports = { DIR, FILE, load, save, getKey, ENV };
