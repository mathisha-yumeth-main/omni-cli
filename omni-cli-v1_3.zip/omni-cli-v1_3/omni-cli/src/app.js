'use strict';
const fs = require('fs'), path = require('path'), os = require('os'), readline = require('readline');
const { spawn, spawnSync, execFileSync } = require('child_process');
const cfgMod = require('./config'), P = require('./providers'), T = require('./tools'), kb = require('./kb'), S = require('./skills');
const { ui, BRAND, welcome, Spinner, makeSplitter, makeMd, vlen, sleep } = require('./ui');

const VERSION = '1.3.0';
const state = {
  cfg: cfgMod.load(), messages: [], todo: [], skills: [], auto: [], usage: { in: 0, out: 0 },
  extra: '', cwd: process.cwd(), busy: false, abort: null, approveAll: false, rl: null, lastText: '', lastUser: '',
};
const say = (s = '') => process.stdout.write(s + '\n');
const brand = () => BRAND[state.cfg.provider];
const accent = (s) => ui.rgb(brand().rgb, s);
const model = () => state.cfg.models[state.cfg.provider];
const save = () => cfgMod.save(state.cfg);
const ask = (q) => new Promise((r) => (state.rl ? state.rl.question(q, r) : r('')));
const EFFORTS = ['low', 'medium', 'high', 'max'];

// ---------- git / project helpers ----------
const git = (args, cwd = state.cwd, max = 2e6) => execFileSync('git', args, { cwd, encoding: 'utf8', timeout: 8000, maxBuffer: max, stdio: ['ignore', 'pipe', 'ignore'] });
let gitCache = { t: 0, cwd: '', v: null };
function gitInfo() {
  if (gitCache.cwd === state.cwd && Date.now() - gitCache.t < 2500) return gitCache.v;
  let v = null;
  try {
    const branch = git(['rev-parse', '--abbrev-ref', 'HEAD']).trim();
    const dirty = git(['status', '--porcelain']).split('\n').filter(Boolean).length;
    v = { branch, dirty };
  } catch { /* not a repo */ }
  gitCache = { t: Date.now(), cwd: state.cwd, v };
  return v;
}
const STACK_LABEL = { nodejs: 'Node.js', typescript: 'TypeScript', rust: 'Rust', go: 'Go', python: 'Python', java: 'Java', gradle: 'Gradle', kotlin: 'Kotlin', ruby: 'Ruby', php: 'PHP', docker: 'Docker', terraform: 'Terraform', flutter: 'Flutter', elixir: 'Elixir', cmake: 'CMake', swift: 'Swift', deno: 'Deno', bun: 'Bun' };
const stack = () => S.stackOf(fs, path, state.cwd);
const stackLabel = () => stack().map((x) => STACK_LABEL[x] || x).join(' · ');
function diffText(args) { try { return git(['--no-pager', 'diff', '--no-color', ...args]).slice(0, 60000); } catch { return ''; } }
async function withSkills(names, fn) {
  const before = state.skills; state.skills = [...new Set([...before, ...names])];
  try { return await fn(); } finally { state.skills = before; }
}

// ---------- prompts ----------
function systemPrompt() {
  const c = state.cfg, parts = [];
  parts.push(`You are Omni, a capable AI assistant running inside a terminal on ${process.platform === 'win32' ? 'Windows' : process.platform}. Be accurate, direct and helpful. Output is shown in a terminal, so use Markdown sparingly (fenced code blocks are fine). Today is ${new Date().toDateString()}. Working directory: ${state.cwd}.`);
  if (c.effort === 'low') parts.push('Keep answers short and to the point.');
  if (c.agent) parts.push(T.protocol());
  if (c.plan) parts.push('## PLAN MODE\nDo not modify files or run commands. You may read and search to understand the code. Produce a concise numbered implementation plan (files to touch, steps, risks, how to verify) and stop. The user will run it when ready.');
  for (const n of [...new Set([...state.skills, ...state.auto])]) { const s = S.find(n); if (s) parts.push(`## Active skill: ${s.name}\n${s.prompt}`); }
  try { const o = fs.readFileSync(path.join(state.cwd, 'OMNI.md'), 'utf8'); parts.push('## Project instructions (OMNI.md)\n' + o.slice(0, 8000)); } catch { /* none */ }
  if (state.extra) parts.push('## Extra instructions\n' + state.extra);
  const hits = state.lastUser ? kb.search(state.lastUser, 3) : [];
  if (hits.length) parts.push('## Relevant knowledge (from the user\'s knowledge base)\n' + hits.map((h) => `[${h.source}]\n${h.text.slice(0, 1500)}`).join('\n---\n'));
  return parts.join('\n\n');
}

function expandMentions(t) {
  const extra = [];
  t.replace(/(^|\s)@([^\s]+)/g, (m, sp, p) => {
    const f = path.resolve(state.cwd, p.replace(/^~/, os.homedir()));
    try { const st = fs.statSync(f); if (st.isFile() && st.size < 400000) extra.push(`<file path="${p}">\n${fs.readFileSync(f, 'utf8')}\n</file>`); } catch { /* not a file */ }
    return m;
  });
  if (extra.length) say(ui.dim(`  attached ${extra.length} file(s)`));
  return extra.length ? t + '\n\n' + extra.join('\n\n') : t;
}

// ---------- generation ----------
async function generate() {
  const c = state.cfg, ac = new AbortController();
  state.abort = ac; state.busy = true;
  const sp = new Spinner(brand().rgb); sp.begin();
  let started = false, inThink = false, acc = '';
  const t0 = Date.now(); let thinkChars = 0;
  const sys = systemPrompt();
  const write = (s) => process.stdout.write(s);
  const md = makeMd(brand().rgb);
  const display = (s) => {
    if (!started) { s = s.replace(/^\s+/, ''); if (!s) return; sp.stop(); if (inThink) { write('\n\n'); inThink = false; } write(accent('●') + ' '); started = true; }
    write(md.push(s));
  };
  const toolSplit = c.agent ? makeSplitter('<tool>', '</tool>', display, () => {}) : null;
  const onText = (t) => { acc += t; sp.tokens += t.length / 4; toolSplit ? toolSplit.push(t) : display(t); };
  const onThink = (t) => {
    thinkChars += t.length;
    sp.tokens += t.length / 4;
    if (!c.thinkingView || started) return;
    if (!inThink) { sp.stop(); inThink = true; write(ui.dim(ui.italic('∴ Thinking…')) + '\n'); }
    write(ui.dim(ui.italic(t)));
  };
  let usage = { in: 0, out: 0 }, aborted = false;
  try {
    const r = await P.chat(c, { messages: state.messages, system: sys, signal: ac.signal, onText, onThink });
    usage = r.usage;
  } catch (e) {
    if (e.name === 'AbortError' || ac.signal.aborted) aborted = true; else { sp.stop(); state.busy = false; throw e; }
  }
  if (toolSplit) toolSplit.flush();
  if (started) write(md.flush());
  sp.stop(); state.busy = false;
  if (started || inThink) write('\n');
  if (aborted) say(ui.yellow('  ⎋ interrupted'));
  const secs = ((Date.now() - t0) / 1000).toFixed(1);
  const i = usage.in || 0, o = usage.out || Math.round(acc.length / 4);
  state.usage.in += i; state.usage.out += o;
  const sec = (Date.now() - t0) / 1000;
  state.last = { at: new Date().toISOString(), provider: c.provider, model: model(), effort: c.effort, agent: !!c.agent, plan: !!c.plan,
    secs: sec, in: i, out: o, estimated: !usage.out, tps: sec > 0 ? o / sec : 0, thinkChars, chars: acc.length,
    ctxTokens: Math.round((sys.length + state.messages.reduce((n, m) => n + m.content.length, 0)) / 4), numCtx: c.provider === 'ollama' ? (usage.numCtx || c.numCtx) : 0,
    skills: [...new Set([...state.skills, ...state.auto])], messages: state.messages.length, aborted };
  if (state.turn) { state.turn.steps++; state.turn.in += i; state.turn.out += o; state.turn.secs += sec; state.last.turn = state.turn; }
  try { fs.writeFileSync(path.join(cfgMod.DIR, 'last.json'), JSON.stringify(state.last)); } catch { /* read-only home */ }
  if (process.stdout.isTTY) say(ui.dim(`  ${secs}s · ↑${i} ↓${o} tokens`));
  return { text: acc, aborted };
}

function parseCalls(text) {
  const out = [], re = /<tool>([\s\S]*?)<\/tool>/g; let m;
  while ((m = re.exec(text))) {
    try { const j = JSON.parse(m[1].trim()); out.push({ name: j.name, args: j.args || {} }); }
    catch (e) { out.push({ error: e.message }); }
  }
  return out;
}

function printCall(call) {
  let s = Object.entries(call.args || {}).map(([k, v]) => `${k}: ${JSON.stringify(typeof v === 'string' && v.length > 60 ? v.slice(0, 57) + '…' : v)}`).join(', ');
  if (s.length > 110) s = s.slice(0, 107) + '…';
  say(`${accent('●')} ${ui.bold(call.name)}${ui.dim('(' + s + ')')}`);
}
function printResult(name, r) {
  if (name === 'todo') { r.split('\n').forEach((l) => say('  ' + ui.dim(l))); return; }
  const ls = r.split('\n'), first = ls.find((l) => l.trim()) || '';
  say(ui.dim(`  ⎿ ${first.slice(0, 120)}${ls.length > 1 ? ` … (+${ls.length - 1} lines)` : ''}`));
}

async function approve(desc) {
  say(ui.yellow('  ? ' + desc));
  const a = (await ask(ui.yellow('  Allow? ') + ui.dim('[y]es / [n]o / [a]lways this session › '))).trim().toLowerCase();
  if (a === 'a' || a === 'always') { state.approveAll = true; return true; }
  return a === 'y' || a === 'yes';
}

async function runTools(calls) {
  const ctx = { cwd: state.cwd, todo: state.todo, ask };
  const results = [];
  for (const call of calls) {
    if (call.error) { results.push(`<tool_result name="invalid">Invalid tool call JSON: ${call.error}</tool_result>`); continue; }
    printCall(call);
    const tool = T.get(call.name);
    let res;
    if (!tool) res = `Unknown tool "${call.name}". Available: ${T.TOOLS.map((t) => t.name).join(', ')}`;
    else {
      const d = tool.danger && tool.danger(call.args || {});
      if (d && state.cfg.plan) res = 'Blocked: plan mode is on, so tools that change files or run commands are disabled. Write the plan instead.';
      else if (d && !state.cfg.autoApprove && !state.approveAll && !(await approve(d))) res = 'User denied this action.';
      if (res === undefined) res = await T.exec(tool, call.args, ctx);
    }
    printResult(call.name, res);
    results.push(`<tool_result name="${call.name}">\n${res}\n</tool_result>`);
  }
  return results.join('\n');
}

// routeOn: text the skill router looks at (defaults to the message itself; '' disables routing, e.g. for pasted diffs)
async function runTurn(text, routeOn = text) {
  state.lastUser = text;
  state.turn = { steps: 0, tools: 0, in: 0, out: 0, secs: 0 };
  state.auto = [];
  if (state.cfg.skillsAuto !== false && routeOn) {
    const hints = /\.[a-z0-9]+\b|@/i.test(routeOn) ? stack() : [];
    state.auto = S.route(routeOn, state.cfg.skillsMax || 4, hints).map((x) => x.name).filter((n) => !state.skills.includes(n));
    if (state.auto.length && process.stdout.isTTY) say(ui.dim('  ⚡ skills: ' + state.auto.join(', ')));
  }
  state.messages.push({ role: 'user', content: expandMentions(text) });
  for (let step = 0; step < (state.cfg.maxSteps || 25); step++) {
    const r = await generate();
    let clean = r.text.split('<tool_result')[0].trim();
    if (r.aborted && !clean) { state.messages.pop(); return; }
    state.messages.push({ role: 'assistant', content: clean || '(no response)' });
    state.lastText = clean.replace(/<tool>[\s\S]*?<\/tool>/g, '').trim() || state.lastText;
    if (r.aborted || !state.cfg.agent) return;
    const calls = parseCalls(clean);
    if (!calls.length) return;
    state.turn.tools += calls.length;
    state.messages.push({ role: 'user', content: await runTools(calls) });
    if (step === (state.cfg.maxSteps || 25) - 1) say(ui.yellow('  Reached the step limit. Type "continue" to keep going.'));
  }
}

async function quietChat(prompt, fresh = false) {
  const sp = new Spinner(brand().rgb); sp.begin();
  try {
    const r = await P.chat({ ...state.cfg, effort: 'low' }, { messages: [...(fresh ? [] : state.messages), { role: 'user', content: prompt }],
      system: fresh ? 'You are a precise assistant. Follow the output format exactly.' : 'You summarize conversations accurately and concisely.', signal: undefined, onText: (t) => { sp.tokens += t.length / 4; }, onThink: () => {} });
    return r.text;
  } finally { sp.stop(); }
}

// ---------- display helpers ----------
async function showLogo(animate) {
  const lines = welcome({ provider: state.cfg.provider, model: model(), effort: state.cfg.effort, agent: state.cfg.agent,
    skills: state.skills.length, nskills: S.all.length, auto: state.cfg.skillsAuto !== false, plan: state.cfg.plan,
    version: VERSION, cwd: state.cwd, git: gitInfo(), stack: stackLabel() });
  say();
  for (const l of lines) { say(l); if (animate && process.stdout.isTTY) await sleep(35); }
}
function statusRule() {
  const c = state.cfg, cols = Math.min(process.stdout.columns || 80, 120);
  const g = gitInfo();
  const t = ` ${brand().label} · ${model()} · effort:${c.effort}${c.agent ? ' · agent' : ''}${c.plan ? ' · plan' : ''}${state.skills.length ? ' · skills:' + state.skills.length : ''}${g ? ` · git:${g.branch}${g.dirty ? '*' + g.dirty : ''}` : ''} `;
  say('\n' + ui.rgb(brand().rgb, '── ') + ui.dim(t) + ui.rgb(brand().rgb, '─'.repeat(Math.max(2, cols - vlen('── ' + t)))));
}
function wrapList(items, indent = '  ') {
  const cols = Math.min(process.stdout.columns || 100, 110) - indent.length; let line = '';
  const out = [];
  for (const it of items) { if (line && vlen(line + it) + 2 > cols) { out.push(indent + line); line = ''; } line += it + '  '; }
  if (line) out.push(indent + line);
  return out.join('\n');
}

async function pick(title, items) {
  say(ui.bold(title));
  items.forEach((it, i) => say(`  ${ui.dim(String(i + 1).padStart(2))}  ${it}`));
  const a = (await ask(ui.dim('  number or name (Enter to cancel) › '))).trim();
  if (!a) return null;
  const n = Number(a);
  return Number.isInteger(n) && items[n - 1] ? items[n - 1] : a;
}

// If the configured Ollama model isn't installed, fall back to the first installed model that can chat.
async function ensureOllamaModel() {
  try {
    const ms = (await P.chatModels(state.cfg)).map((x) => x.id), cur = state.cfg.models.ollama;
    if (ms.length && !ms.includes(cur) && !ms.includes(cur + ':latest')) { state.cfg.models.ollama = ms[0]; save(); }
  } catch { /* offline */ }
}

async function setProvider(name) {
  let wanted = '';
  if (name.includes(':') ) { const i = name.indexOf(':'); wanted = name.slice(i + 1); name = name.slice(0, i); }
  name = P.ALIASES[name] || name;
  if (!P.PROVIDERS[name]) return say(ui.red(`Unknown provider "${name}". Choose: ${Object.keys(P.PROVIDERS).join(', ')}`));
  state.cfg.provider = name;
  if (wanted) { state.cfg.models[name] = await P.resolveModel(state.cfg, name, wanted); }
  else if (name === 'ollama') await ensureOllamaModel();
  save();
  await showLogo(true);
  if (name !== 'ollama' && !cfgMod.getKey(state.cfg, name)) say(ui.yellow(`\n  No API key for ${brand().label}. Run:  /key ${name} <your-key>   (or set ${cfgMod.ENV[name]})`));
}

function copyToClipboard(text) {
  const [cmd, ...args] = process.platform === 'win32' ? ['powershell', '-NoProfile', '-Command', '$input | Set-Clipboard']
    : process.platform === 'darwin' ? ['pbcopy'] : ['xclip', '-selection', 'clipboard'];
  const p = spawn(cmd, args);
  p.on('error', () => say(ui.red('No clipboard tool found (Linux: install xclip).')));
  p.stdin.on('error', () => {}); p.stdin.end(text);
}

// ---------- info ----------
const n0 = (n) => Math.round(n).toLocaleString('en-US');
function infoLast(l) {
  if (!l) return '  no response yet in this session — ask something, then run /info -l';
  const row = (k, v) => `  ${ui.dim(k.padEnd(10))} ${v}`, out = [ui.bold('  Last response') + ui.dim('  ' + new Date(l.at).toLocaleString())];
  out.push(row('model', `${l.provider} / ${l.model}   effort ${l.effort}${l.agent ? ' · agent' : ''}${l.plan ? ' · plan' : ''}`));
  out.push(row('time', `${l.secs.toFixed(1)}s   ${ui.dim(l.tps ? `≈ ${l.tps.toFixed(1)} tokens/s` : '')}`));
  out.push(row('tokens', `↑ ${n0(l.in)} in · ↓ ${n0(l.out)} out · total ${n0(l.in + l.out)}${l.estimated ? ui.dim('  (output estimated)') : ''}`));
  const used = l.in || l.ctxTokens;
  out.push(row('context', `~${n0(used)} tokens in use${l.numCtx ? ` of ${n0(l.numCtx)} (${Math.round((used / l.numCtx) * 100)}%)` + (used > l.numCtx * 0.85 ? ui.yellow('  near limit — /compact or /ctx') : '') : ''}`));
  out.push(row('output', `${n0(l.chars)} chars${l.thinkChars ? ` · thinking ${n0(l.thinkChars)} chars` : ''}`));
  out.push(row('skills', l.skills && l.skills.length ? l.skills.join(', ') : ui.dim('none')));
  if (l.turn && l.turn.tools) out.push(row('agent turn', `${l.turn.tools} tool call(s) in ${l.turn.steps} step(s) · ↑${n0(l.turn.in)} ↓${n0(l.turn.out)} tokens · ${l.turn.secs.toFixed(1)}s total`));
  out.push(row('history', `${l.messages} messages`));
  out.push(row('finish', l.aborted ? ui.yellow('interrupted') : ui.green('completed')));
  return out.join('\n');
}
function infoSession() {
  const c = state.cfg;
  return [ui.bold('  Session'),
    `  ${ui.dim('provider  ')} ${c.provider} / ${model()}   effort ${c.effort}`,
    `  ${ui.dim('tokens    ')} ↑ ${n0(state.usage.in)} in · ↓ ${n0(state.usage.out)} out · ${state.messages.length} messages`,
    `  ${ui.dim('modes     ')} agent ${c.agent ? 'on' : 'off'} · plan ${c.plan ? 'on' : 'off'} · auto-approve ${c.autoApprove ? 'on' : 'off'} · skills ${c.skillsAuto === false ? 'manual' : 'auto'}`,
    `  ${ui.dim('skills    ')} ${state.skills.length ? 'pinned: ' + state.skills.join(', ') : 'none pinned'}${state.auto.length ? ' · last auto: ' + state.auto.join(', ') : ''}`,
    `  ${ui.dim('dir       ')} ${state.cwd}`,
    `  ${ui.dim('config    ')} ${cfgMod.FILE}`].join('\n');
}

// ---------- commands ----------
const CMDS = {};
const def = (names, desc, fn) => { const n = names.split(','); CMDS[n[0]] = { desc, fn, names: n }; n.slice(1).forEach((a) => (CMDS[a] = CMDS[n[0]])); };

def('help,?', 'Show this help', () => {
  say(ui.bold('\nCommands'));
  const seen = new Set();
  for (const [k, v] of Object.entries(CMDS)) { if (seen.has(v)) continue; seen.add(v); say(`  ${accent(('/' + v.names.join(', /')).padEnd(24))} ${v.desc}`); }
  say(ui.bold('\nShortcuts'));
  say(`  ${accent('!<cmd>'.padEnd(24))} run a shell command\n  ${accent('@path/to/file'.padEnd(24))} attach a file's contents to your message\n  ${accent('line ending with \\'.padEnd(24))} continue on the next line\n  ${accent('Ctrl+C'.padEnd(24))} interrupt generation (twice to exit)\n  ${accent('Tab'.padEnd(24))} complete commands`);
});
def('provider,p', 'Switch provider: ollama, claude, gemini, openai, xai', async (a) => {
  let n = a;
  if (!n) { n = await pick('Providers', Object.keys(P.PROVIDERS).map((k) => `${k.padEnd(8)} ${ui.dim(state.cfg.models[k])}${k === state.cfg.provider ? accent('  ◀ current') : ''}`)); if (n) n = n.split(/\s+/)[0]; }
  if (n) await setProvider(n);
});
def('model,m', 'Set the model: /model sonnet | opus | qwen3 | exact id (no argument = pick from list)', async (a) => {
  let m = a;
  if (!m) {
    say(ui.dim('  fetching models…'));
    try { const ms = state.cfg.provider === 'ollama' ? (await P.chatModels(state.cfg)).map((x) => x.id) : await P.listModels(state.cfg, state.cfg.provider); m = await pick(`Models for ${brand().label} (current: ${model()})`, ms.slice(0, 60)); }
    catch (e) { return say(ui.red('  ' + e.message) + ui.dim(`\n  Set one manually: /model <name>   (current: ${model()})`)); }
  }
  if (m) {
    const r = await P.resolveModel(state.cfg, state.cfg.provider, m);
    state.cfg.models[state.cfg.provider] = r; save();
    say(`  model → ${accent(r)}${r !== m ? ui.dim('  (matched "' + m + '")') : ''}`);
    if (state.cfg.provider === 'ollama') {
      try {
        const have = (await P.modelInfo(state.cfg, 'ollama')).map((x) => x.id);
        if (!have.includes(r) && !have.includes(r + ':latest')) say(ui.yellow(`  ⚠ "${r}" is not installed. Install it:  ollama pull ${r}`) + ui.dim(have.length ? `\n    installed: ${have.join(', ')}` : ''));
      } catch (e) { say(ui.yellow('  ⚠ ' + e.message)); }
    }
  }
});
const capTags = (c) => (c || []).map((x) => ({ thinking: 'think', tools: 'tools', vision: 'vision', embedding: 'embed-only' }[x])).filter(Boolean);
def('models,ml', 'List models: /models [filter] | all (every provider with a key)', async (a) => {
  const gb = (n) => (n ? (n / 1e9).toFixed(1) + ' GB' : '');
  const show = async (p, filter) => {
    const list = (await P.modelInfo(state.cfg, p)).filter((m) => !filter || m.id.toLowerCase().includes(filter));
    say(ui.bold(`\n  ${P.PROVIDERS[p].label}`) + ui.dim(`  ${list.length} model(s)`) + (P.MODEL_ALIASES[p] ? ui.dim('   aliases: ' + Object.keys(P.MODEL_ALIASES[p]).join(', ')) : ''));
    if (!list.length) return say(ui.dim(p === 'ollama' ? '  none — install one with:  ollama pull qwen3-coder' : '  no match'));
    list.slice(0, 80).forEach((m, i) => say(`  ${ui.dim(String(i + 1).padStart(3))} ${m.id === state.cfg.models[p] || m.id === state.cfg.models[p] + ':latest' ? accent('▶ ' + m.id) : '  ' + m.id}${m.size ? ui.dim('  ' + [gb(m.size), m.params, m.quant, m.ctxMax ? Math.round(m.ctxMax / 1024) + 'k ctx' : '', ...capTags(m.caps)].filter(Boolean).join(' · ')) : ''}`));
    if (list.length > 80) say(ui.dim(`  …and ${list.length - 80} more — narrow with /models <filter>`));
  };
  const f = a.trim().toLowerCase();
  if (f === 'all') {
    for (const p of Object.keys(P.PROVIDERS)) { try { await show(p, ''); } catch (e) { say(ui.dim(`\n  ${P.PROVIDERS[p].label}: ${e.message}`)); } }
    return;
  }
  try { await show(state.cfg.provider, f); say(ui.dim('\n  switch with /model <name or alias>')); } catch (e) { say(ui.red('  ' + e.message)); }
});
def('info,i', 'Show details: /info -l (last response: tokens, speed, context…) | /info (session)', (a) => {
  if (/(^|\s)(-l|--last|last)\b/.test(a)) return say('\n' + infoLast(state.last) + '\n');
  say('\n' + infoSession() + '\n\n' + infoLast(state.last) + '\n');
});
def('history,hist', 'Show your recent prompts: /history [n]', (a) => {
  let h = []; try { h = fs.readFileSync(path.join(cfgMod.DIR, 'history'), 'utf8').split('\n').filter((l) => l && !l.startsWith('/key')); } catch { /* none */ }
  const n = Math.max(1, Number(a) || 15), rows = h.slice(-n);
  say(rows.length ? rows.map((l, i) => `  ${ui.dim(String(h.length - rows.length + i + 1).padStart(4))}  ${l.slice(0, 110)}`).join('\n') : '  no history yet');
});
def('edit', 'Write a long prompt in your editor ($EDITOR, default nano/notepad)', async () => {
  const f = path.join(os.tmpdir(), `omni-prompt-${Date.now()}.md`); fs.writeFileSync(f, '');
  const ed = process.env.VISUAL || process.env.EDITOR || (process.platform === 'win32' ? 'notepad' : 'nano');
  state.rl.pause();
  await new Promise((r) => { const p = spawn(ed + ' "' + f + '"', { shell: true, stdio: 'inherit' }); p.on('close', r); p.on('error', r); });
  state.rl.resume();
  let t = ''; try { t = fs.readFileSync(f, 'utf8').trim(); fs.unlinkSync(f); } catch { /* ignore */ }
  if (!t) return say('  empty — cancelled');
  say(ui.dim(`  sending ${t.split('\n').length} line(s)\n`)); await runTurn(t);
});
def('pr', 'Write a pull-request description from your branch: /pr [base]', async (a) => {
  const base = a || 'main', d = diffText([base + '...HEAD']) || diffText(['HEAD']);
  if (!d.trim()) return say('  no changes found against ' + base);
  let log = ''; try { log = git(['log', '--pretty=- %s', base + '..HEAD']); } catch { /* no base */ }
  say(); await withSkills(['pr-description'], () => runTurn(`Write a pull request description for these changes.\n\nCommits:\n${log || '(n/a)'}\n\n\`\`\`diff\n${d}\n\`\`\``, ''));
});
def('changelog', 'Changelog entry from commits: /changelog [since-ref]', async (a) => {
  let log = ''; try { log = git(['log', '--pretty=%h %s', a ? a + '..HEAD' : '-30']); } catch { return say(ui.red('  not a git repo (or bad ref)')); }
  if (!log.trim()) return say('  no commits');
  say(); await withSkills(['changelog', 'release-notes'], () => runTurn('Turn these commits into a changelog entry:\n' + log, ''));
});
const fileCmd = (name, desc, skills, prompt, agent) => def(name, desc, async (a) => {
  if (!a) return say(ui.red(`Usage: /${name} <file>`));
  const f = path.resolve(state.cwd, a.replace(/^~/, os.homedir()));
  let src; try { src = fs.readFileSync(f, 'utf8').slice(0, 60000); } catch { return say(ui.red('  cannot read ' + a)); }
  const was = state.cfg.agent; if (agent) state.cfg.agent = true;
  say();
  try { await withSkills(skills, () => runTurn(`${prompt(a)}\n\n\`\`\`\n${src}\n\`\`\``, a)); } finally { state.cfg.agent = was; }
});
fileCmd('tests', 'Generate unit tests for a file: /tests <file>', ['write-tests'], (f) => `Write thorough unit tests for ${f} using the project's existing test framework. Save them in the conventional location with your write_file tool, then run them.`, true);
fileCmd('fix', 'Find and fix bugs in a file (agent): /fix <file>', ['debug', 'refactor'], (f) => `Find real bugs in ${f} and fix them with minimal edits using edit_file. Explain each fix; run tests if available.`, true);
fileCmd('docs', 'Add doc comments to a file (agent): /docs <file>', ['doc-comments'], (f) => `Add accurate doc comments/docstrings to ${f} without changing behavior. Apply them with edit_file.`, true);
fileCmd('optimize', 'Performance review of a file: /optimize <file>', ['optimize', 'profile-perf'], (f) => `Find performance bottlenecks in ${f}; rank fixes by impact and show the improved code.`, false);
fileCmd('security', 'Security audit of a file: /security <file>', ['security-audit', 'secrets-scan'], (f) => `Security-audit ${f}: severity, exploit scenario and fix for each finding.`, false);
def('key', 'Save an API key: /key <provider> <key>  (or /key <key> for current)', (a) => {
  const [x, y] = a.split(/\s+/);
  let p = state.cfg.provider, k = x;
  if (y) { p = P.ALIASES[x] || x; k = y; }
  if (!P.PROVIDERS[p] || !k) return say(ui.red('Usage: /key <provider> <key>'));
  state.cfg.keys[p] = k; save();
  say(`  ${accent('✓')} key saved for ${p} ${ui.dim('(stored in ' + cfgMod.FILE + ')')}`);
});
def('host', 'Set the Ollama server URL (default http://127.0.0.1:11434)', (a) => {
  if (!a) return say(`  ${P.hostOf(state.cfg)}`);
  state.cfg.hosts.ollama = a; save(); say(`  ollama host → ${a}`);
});
def('effort,e', 'Set thinking effort: low | medium | high | max', (a) => {
  if (!EFFORTS.includes(a)) return say(`  effort: ${accent(state.cfg.effort)}   options: ${EFFORTS.join(' | ')}\n  ${ui.dim('Maps to thinking budgets (Claude/Gemini), reasoning effort (OpenAI/xAI) or think mode (Ollama).')}`);
  state.cfg.effort = a; save(); say(`  effort → ${accent(a)} ${ui.dim('▁▃▅▇'.slice(0, EFFORTS.indexOf(a) + 1))}`);
});
def('thinking', 'Show/hide the model\'s thinking stream', () => { state.cfg.thinkingView = !state.cfg.thinkingView; save(); say(`  thinking display ${state.cfg.thinkingView ? 'on' : 'off'}`); });
def('agent,a', 'Toggle agent mode (model can use tools): /agent [on|off]', (a) => {
  state.cfg.agent = a ? a === 'on' : !state.cfg.agent; save();
  say(`  agent mode ${state.cfg.agent ? accent('on') + ui.dim(' — the model can read/write files, run commands, search the web…') : 'off'}`);
});
def('auto', 'Toggle auto-approve for risky tools (writes, commands)', (a) => {
  state.cfg.autoApprove = a ? a === 'on' : !state.cfg.autoApprove; save(); state.approveAll = false;
  say(`  auto-approve ${state.cfg.autoApprove ? ui.yellow('ON — tools run without asking') : 'off'}`);
});
def('tools', 'List agent tools', () => T.TOOLS.forEach((t) => say(`  ${accent(t.sig.padEnd(44))} ${ui.dim(t.desc)}`)));
def('tool', 'Run a tool manually: /tool <name> {json args}', async (a) => {
  const i = a.indexOf(' '), name = i < 0 ? a : a.slice(0, i), tool = T.get(name);
  if (!tool) return say(ui.red('Unknown tool. See /tools'));
  let args = {}; try { if (i > 0) args = JSON.parse(a.slice(i + 1)); } catch { return say(ui.red('Args must be JSON')); }
  const d = tool.danger && tool.danger(args);
  if (d && !(await approve(d))) return say('  cancelled');
  say(await T.exec(tool, args, { cwd: state.cwd, todo: state.todo, ask }));
});
def('skills', 'Browse skills: /skills [search|category] | auto on|off | max <n>', (a) => {
  const q = a.toLowerCase();
  const am = /^auto\s*(on|off)?$/.exec(q), mx = /^max\s+(\d+)$/.exec(q);
  if (am) { state.cfg.skillsAuto = am[1] ? am[1] === 'on' : state.cfg.skillsAuto === false; save(); return say(`  skill auto-routing ${state.cfg.skillsAuto ? accent('on') + ui.dim(` — all ${S.all.length} skills are considered for every message; the best ${state.cfg.skillsMax} are injected`) : 'off — only pinned skills are used'}`); }
  if (mx) { state.cfg.skillsMax = Math.min(8, Math.max(1, Number(mx[1]))); save(); return say(`  router injects up to ${state.cfg.skillsMax} skills per message`); }
  if (!q || q === 'all') {
    say(ui.bold(`\n${S.all.length} skills`) + ui.dim(`  — auto-routing ${state.cfg.skillsAuto === false ? 'OFF' : 'ON (best ' + state.cfg.skillsMax + ' picked per message)'} · pin with /skill <name> · search: /skills <word>`));
    for (const c of S.cats()) { const l = S.all.filter((s) => s.cat === c); say('\n' + accent(`${c} (${l.length})`)); say(wrapList(l.map((s) => s.name.replace(/^expert-/, '')))); }
    return;
  }
  const hits = S.all.filter((s) => s.cat === q || s.name.includes(q) || s.desc.toLowerCase().includes(q));
  if (!hits.length) return say('  no skills match');
  hits.slice(0, 60).forEach((s) => say(`  ${accent(s.name.padEnd(26))} ${ui.dim(s.desc)}`));
  if (hits.length > 60) say(ui.dim(`  …and ${hits.length - 60} more`));
});
def('skill,s', 'Pin skills (always on): /skill <name…> | off [name] | (none = show active)', (a) => {
  const w = a.split(/\s+/).filter(Boolean);
  if (!w.length) return say((state.skills.length ? `  pinned: ${state.skills.map(accent).join(', ')}\n` : '  nothing pinned. Try /skills\n') + `  auto-routed last message: ${state.auto.join(', ') || ui.dim('none')}`);
  if (w[0] === 'off') { state.skills = w[1] ? state.skills.filter((n) => n !== (S.find(w[1]) || {}).name) : []; return say(`  active: ${state.skills.join(', ') || 'none'}`); }
  for (const n of w) { const s = S.find(n); if (!s) say(ui.red(`  unknown skill "${n}"`)); else if (!state.skills.includes(s.name)) { state.skills.push(s.name); say(`  ${accent('✓')} ${s.name} ${ui.dim('— ' + s.desc)}`); } }
});
def('kb,knowledge', 'Knowledge base: add <path|text> | list | rm <n> | search <q> | clear', (a) => {
  const [sub, ...r] = a.split(/\s+/), rest = r.join(' ');
  if (sub === 'add') {
    if (!rest) return say(ui.red('Usage: /kb add <file|folder|text>'));
    const p = path.resolve(state.cwd, rest.replace(/^~/, os.homedir()));
    if (fs.existsSync(p)) say(`  added ${accent(kb.addPath(p))} file(s)`); else { kb.addText(rest, 'note:' + Date.now()); say('  saved note'); }
  } else if (sub === 'list' || !sub) {
    const l = kb.list(); if (!l.length) return say('  knowledge base is empty — /kb add <file|folder|text>');
    l.forEach((d) => say(`  ${ui.dim(String(d.id).padStart(3))} ${d.source.slice(0, 90)} ${ui.dim(d.chunks + ' chunks')}`));
  } else if (sub === 'rm') say(`  removed ${kb.remove(rest)}`);
  else if (sub === 'search') kb.search(rest, 5).forEach((h) => say(`${accent(h.source)} ${ui.dim(h.score.toFixed(2))}\n  ${h.text.slice(0, 300).replace(/\n/g, ' ')}\n`));
  else if (sub === 'clear') { kb.clear(); say('  cleared'); }
  else say(ui.red('Usage: /kb add|list|rm|search|clear'));
});
def('system', 'Add extra instructions for this session (empty = clear)', (a) => { state.extra = a; say(a ? '  system note set' : '  system note cleared'); });
def('clear,new', 'Clear the conversation', () => { state.messages = []; state.todo = []; state.lastText = ''; say('  conversation cleared'); });
const isPlainUser = (m) => m.role === 'user' && !m.content.startsWith('<tool_result');
def('undo', 'Remove the last exchange', () => {
  while (state.messages.length && !isPlainUser(state.messages[state.messages.length - 1])) state.messages.pop();
  state.messages.pop(); say('  removed last exchange');
});
def('retry', 'Re-run your last message', async () => {
  if (!state.lastUser) return say('  nothing to retry');
  while (state.messages.length && !isPlainUser(state.messages[state.messages.length - 1])) state.messages.pop();
  state.messages.pop(); await runTurn(state.lastUser);
});
def('compact', 'Summarize the conversation to free up context', async () => {
  if (state.messages.length < 2) return say('  nothing to compact');
  const s = await quietChat('Summarize our conversation so far in under 400 words: goals, decisions, files touched, open tasks. This will replace the history.');
  state.messages = [{ role: 'user', content: 'Summary of the earlier conversation:\n' + s }, { role: 'assistant', content: 'Understood — I have the context.' }];
  say(`  ${accent('✓')} compacted to ${s.length} chars`);
});
def('save', 'Save the session: /save [name]', (a) => {
  const d = path.join(cfgMod.DIR, 'sessions'); fs.mkdirSync(d, { recursive: true });
  const n = a || new Date().toISOString().slice(0, 16).replace(/[:T]/g, '-');
  fs.writeFileSync(path.join(d, n + '.json'), JSON.stringify({ provider: state.cfg.provider, skills: state.skills, messages: state.messages }));
  say(`  saved as ${accent(n)}`);
});
def('load', 'Load a saved session: /load <name>', (a) => {
  try { const j = JSON.parse(fs.readFileSync(path.join(cfgMod.DIR, 'sessions', a + '.json'), 'utf8')); state.messages = j.messages; state.skills = j.skills || []; say(`  loaded ${a} (${j.messages.length} messages)`); }
  catch { say(ui.red('  session not found — see /sessions')); }
});
def('sessions', 'List saved sessions', () => {
  const d = path.join(cfgMod.DIR, 'sessions');
  say(wrapList(fs.existsSync(d) ? fs.readdirSync(d).filter((f) => f.endsWith('.json')).map((f) => f.slice(0, -5)) : ['(none)']));
});
def('export', 'Export the conversation to Markdown: /export [file]', (a) => {
  const f = path.resolve(state.cwd, a || 'omni-chat.md');
  fs.writeFileSync(f, state.messages.map((m) => `## ${m.role === 'user' ? 'You' : 'Omni'}\n\n${m.content}\n`).join('\n'));
  say(`  exported to ${f}`);
});
def('copy', 'Copy the last answer to the clipboard (/copy code = last code block)', (a) => {
  if (!state.lastText) return say('  nothing to copy');
  if (a === 'code') {
    const blocks = [...state.lastText.matchAll(/```[^\n]*\n([\s\S]*?)```/g)].map((m) => m[1].replace(/\n$/, ''));
    if (!blocks.length) return say('  no code block in the last answer');
    copyToClipboard(blocks[blocks.length - 1]); return say(`  copied last code block (${blocks.length} in answer)`);
  }
  copyToClipboard(state.lastText); say('  copied');
});
def('usage,cost', 'Token usage this session', () => say(`  ↑ ${state.usage.in} input · ↓ ${state.usage.out} output tokens · ${state.messages.length} messages`));
def('cd', 'Change working directory', (a) => {
  const p = path.resolve(state.cwd, (a || os.homedir()).replace(/^~/, os.homedir()));
  if (!fs.existsSync(p) || !fs.statSync(p).isDirectory()) return say(ui.red('  not a directory'));
  state.cwd = p; say('  ' + p);
});
def('pwd', 'Show working directory', () => say('  ' + state.cwd));
def('logo', 'Show the welcome logo', () => showLogo(true));
def('init', 'Let the agent analyze this project and write OMNI.md', async () => {
  const was = state.cfg.agent; state.cfg.agent = true;
  try { await runTurn('Explore this project with your tools (project_summary, tree, read_file, grep) and write an OMNI.md file in the project root documenting purpose, structure, build/test/run commands and conventions. Keep it under 80 lines.'); }
  finally { state.cfg.agent = was; }
});
def('doctor', 'Check configuration and connectivity', async () => {
  say(`  node ${process.version} · ${process.platform} · config ${cfgMod.FILE}`);
  for (const p of Object.keys(P.PROVIDERS)) {
    let s;
    if (p === 'ollama') { try { s = ui.green(`reachable, ${(await P.listModels(state.cfg, p)).length} models`); } catch { s = ui.red(`not reachable at ${P.hostOf(state.cfg)}`); } }
    else s = cfgMod.getKey(state.cfg, p) ? ui.green('key set') : ui.dim('no key');
    say(`  ${(p === state.cfg.provider ? accent('▶ ') : '  ') + p.padEnd(8)} ${state.cfg.models[p].padEnd(24)} ${s}`);
  }
});

// ---------- developer commands ----------
def('status,st', 'Project, git and session status', () => {
  const g = gitInfo(), t = T.testCommand(state.cwd);
  say(`  ${ui.dim('dir     ')} ${state.cwd}`);
  say(`  ${ui.dim('git     ')} ${g ? `${g.branch}${g.dirty ? ui.yellow('  ' + g.dirty + ' changed file(s)') : ui.green('  clean')}` : ui.dim('not a git repository')}`);
  say(`  ${ui.dim('stack   ')} ${stackLabel() || ui.dim('unknown')}`);
  say(`  ${ui.dim('tests   ')} ${t || ui.dim('none detected')}`);
  say(`  ${ui.dim('model   ')} ${brand().label} / ${model()}  effort:${state.cfg.effort}  agent:${state.cfg.agent ? 'on' : 'off'}  plan:${state.cfg.plan ? 'on' : 'off'}  ctx:${state.cfg.numCtx}`);
  say(`  ${ui.dim('skills  ')} ${S.all.length} (auto-routing ${state.cfg.skillsAuto === false ? 'off' : 'on'}, pinned ${state.skills.length})`);
});
def('diff', 'Show the git diff (colored): /diff [--staged|file…]', (a) => new Promise((r) => {
  const p = spawn('git', ['--no-pager', 'diff', '--color=always', ...(a ? a.split(/\s+/) : [])], { cwd: state.cwd, stdio: 'inherit' });
  p.on('close', r); p.on('error', () => { say(ui.red('  git not found')); r(); });
}));
def('review', 'AI code review of your changes: /review [staged|branch <base>|<file>]', async (a) => {
  const w = a.split(/\s+/).filter(Boolean);
  let d = '', what = 'uncommitted changes';
  if (w[0] === 'staged') { d = diffText(['--cached']); what = 'staged changes'; }
  else if (w[0] === 'branch') { const base = w[1] || 'main'; d = diffText([base + '...HEAD']); what = `changes since ${base}`; }
  else if (w[0]) { d = diffText(['HEAD', '--', ...w]); what = w.join(' '); }
  else d = diffText(['HEAD']) || diffText([]);
  if (!d.trim()) return say('  no changes to review (is this a git repo with edits?)');
  say(ui.dim(`  reviewing ${what} — ${d.split('\n').length} diff lines`));
  say();
  await withSkills(['code-review', 'security-audit'], () => runTurn('Review these ' + what + '. Group findings by severity (bug / risk / nit), cite file and line, and give a concrete fix for each. End with a one-line verdict.\n\n```diff\n' + d + '\n```', ''));
});
def('commit', 'AI-written commit message, then commit: /commit [-a]', async (a) => {
  let d = diffText(['--cached']);
  if (!d.trim()) {
    const all = diffText(['HEAD']);
    if (!all.trim()) return say('  nothing to commit');
    if (!(a === '-a' || (await ask(ui.yellow('  Nothing staged. Stage all changes? ') + ui.dim('[y/N] › '))).trim().toLowerCase().startsWith('y'))) return say('  cancelled');
    try { git(['add', '-A']); } catch (e) { return say(ui.red('  git add failed')); }
    d = diffText(['--cached']);
  }
  let recent = ''; try { recent = git(['log', '-5', '--pretty=%s']); } catch { /* new repo */ }
  const msg = (await quietChat('Write a Conventional Commits message for this staged diff: "type(scope): summary" (max 72 chars), blank line, then a short body of bullet points only if useful. Match the style of recent commits:\n' + recent + '\nOutput ONLY the message, no code fences.\n\n' + d, true)).replace(/^```\w*\n?|```$/g, '').trim();
  if (!msg) return say(ui.red('  no message generated'));
  say('\n' + msg.split('\n').map((l) => '  ' + accent('│ ') + l).join('\n') + '\n');
  const ans = (await ask(ui.yellow('  Commit with this message? ') + ui.dim('[y]es / [n]o / [e]dit › '))).trim().toLowerCase();
  let final = msg;
  if (ans.startsWith('e')) final = (await ask(ui.dim('  subject › '))).trim() || msg;
  else if (!ans.startsWith('y')) return say('  cancelled (changes remain staged)');
  try { say(ui.dim(git(['commit', '-m', final]).split('\n')[0])); gitCache.t = 0; } catch (e) { say(ui.red('  commit failed: ' + (e.stderr || e.message))); }
});
def('test', 'Run the project tests; offer to fix failures: /test [command]', async (a) => {
  const cmd = a || T.testCommand(state.cwd);
  if (!cmd) return say(ui.red('  no test command detected — use /test <command>'));
  say(ui.dim('  $ ' + cmd));
  const out = await new Promise((resolve) => {
    let buf = '';
    const p = spawn(cmd, { shell: true, cwd: state.cwd });
    const feed = (d) => { process.stdout.write(d); buf += d; };
    p.stdout.on('data', feed); p.stderr.on('data', feed);
    p.on('close', (code) => resolve({ code, buf })); p.on('error', () => resolve({ code: 1, buf: 'failed to start' }));
  });
  if (out.code === 0) return say(ui.green('\n  ✓ tests passed'));
  say(ui.red(`\n  ✗ tests failed (exit ${out.code})`));
  if (!(await ask(ui.yellow('  Ask the model to fix it (agent mode)? ') + ui.dim('[y/N] › '))).trim().toLowerCase().startsWith('y')) return;
  const was = state.cfg.agent; state.cfg.agent = true;
  try { await withSkills(['fix-failing-test', 'debug'], () => runTurn(`The command \`${cmd}\` fails. Find the root cause using your tools, fix it, and re-run the tests to confirm.\n\nOutput (tail):\n\`\`\`\n${out.buf.slice(-6000)}\n\`\`\``, '')); }
  finally { state.cfg.agent = was; }
});
def('plan', 'Plan mode: the model reads but cannot change anything: /plan [on|off]', (a) => {
  state.cfg.plan = a ? a === 'on' : !state.cfg.plan; save();
  say(`  plan mode ${state.cfg.plan ? accent('on') + ui.dim(' — writes and commands are blocked; ask for a plan, then /plan off to execute') : 'off'}`);
});
def('ctx', 'Set the Ollama context window (tokens): /ctx 16384', (a) => {
  const n = Number(a);
  if (!n) return say(`  context window: ${state.cfg.numCtx} tokens ${ui.dim('(Ollama only; bigger = more memory)')}`);
  state.cfg.numCtx = Math.max(2048, Math.min(1048576, n)); save(); say(`  num_ctx → ${state.cfg.numCtx}`);
});
def('find,grep', 'Search the project: /find <regex>', async (a) => {
  if (!a) return say(ui.red('Usage: /find <regex>'));
  say(await T.exec(T.get('grep'), { pattern: a, ignore_case: true }, { cwd: state.cwd }));
});
def('todo', 'Show the agent\'s task list', () => say(state.todo.length ? state.todo.map((i) => `  ${i.done ? '☑' : '☐'} ${i.text}`).join('\n') : '  no tasks'));
def('explain', 'Explain a source file: /explain <file>', async (a) => {
  if (!a) return say(ui.red('Usage: /explain <file>'));
  const f = path.resolve(state.cwd, a.replace(/^~/, os.homedir()));
  let src; try { src = fs.readFileSync(f, 'utf8').slice(0, 60000); } catch { return say(ui.red('  cannot read ' + a)); }
  say();
  await withSkills(['explain-code'], () => runTurn(`Explain this file (${a}): purpose, structure, key functions, data flow and gotchas.\n\n\`\`\`\n${src}\n\`\`\``, a));
});
// ---------- v1.3: more developer commands ----------
// One non-streaming call that doesn't touch the chat history (used by /each, /bench, /refactor).
async function quiet(prompt, system, cfg = state.cfg) {
  const ac = new AbortController(); state.abort = ac; state.busy = true;
  const t0 = Date.now(); let text = '';
  try {
    const r = await P.chat(cfg, { messages: [{ role: 'user', content: prompt }], system: system || 'You are a precise, helpful assistant.', signal: ac.signal, onText: (s) => { text += s; }, onThink: () => {} });
    return { text: r.text || text, usage: r.usage || {}, secs: (Date.now() - t0) / 1000, aborted: false };
  } catch (e) {
    if (e.name === 'AbortError' || ac.signal.aborted) return { text, usage: {}, secs: (Date.now() - t0) / 1000, aborted: true };
    throw e;
  } finally { state.busy = false; }
}
const toolOut = (name, args = {}) => T.exec(T.get(name), args, { cwd: state.cwd, todo: state.todo, ask });
const tps = (r) => { const o = r.usage.out || Math.round(r.text.length / 4); return r.secs > 0 ? o / r.secs : 0; };

def('each,all', 'Ask EVERY installed Ollama model the same prompt and compare: /each <prompt>', async (a) => {
  if (!a) return say(ui.red('Usage: /each <prompt>'));
  let ms; try { ms = await P.chatModels(state.cfg); } catch (e) { return say(ui.red('  ' + e.message)); }
  if (!ms.length) return say(ui.dim('  no models installed — try: ollama pull qwen3'));
  say(ui.dim(`  asking ${ms.length} installed model(s) one by one — Ctrl+C stops`));
  const rows = [];
  for (const m of ms) {
    const cfg = { ...state.cfg, provider: 'ollama', models: { ...state.cfg.models, ollama: m.id } };
    say('\n' + ui.bold(accent('━━ ' + m.id)) + ui.dim(m.params ? '  ' + m.params : ''));
    const sp = new Spinner(brand().rgb); sp.begin();
    let r;
    try { r = await quiet(a, null, cfg); } catch (e) { sp.stop(); say(ui.red('  ' + e.message)); rows.push({ id: m.id, err: true }); continue; }
    sp.stop();
    if (r.aborted) { say(ui.yellow('  ⎋ stopped')); break; }
    say((r.text.trim() || ui.dim('(empty answer)')) + '\n' + ui.dim(`  ${r.secs.toFixed(1)}s · ${r.usage.out || '~' + Math.round(r.text.length / 4)} tokens · ${tps(r).toFixed(1)} tok/s`));
    rows.push({ id: m.id, secs: r.secs, tps: tps(r) });
  }
  if (rows.length > 1) {
    say(ui.bold('\n  Speed ranking'));
    rows.filter((r) => !r.err).sort((x, y) => y.tps - x.tps).forEach((r, i) => say(`  ${ui.dim(String(i + 1).padStart(2))} ${r.id.padEnd(32)} ${r.tps.toFixed(1).padStart(7)} tok/s  ${ui.dim(r.secs.toFixed(1) + 's')}`));
  }
});
def('bench', 'Benchmark the current model: speed in tokens/s', async () => {
  say(ui.dim(`  benchmarking ${state.cfg.provider} / ${model()} …`));
  const sp = new Spinner(brand().rgb); sp.begin();
  let r; try { r = await quiet('Explain how a hash map works in about 200 words.'); } catch (e) { sp.stop(); return say(ui.red('  ' + e.message)); }
  sp.stop();
  if (r.aborted) return say(ui.yellow('  ⎋ stopped'));
  say(`  ${accent(model())}   ${r.secs.toFixed(1)}s total · ${r.usage.out || '~' + Math.round(r.text.length / 4)} tokens · ${accent(tps(r).toFixed(1) + ' tok/s')}` + (state.cfg.effort !== 'low' ? ui.dim('\n  (thinking models count reasoning time; /effort low for a pure speed test)') : ''));
});

// Run a command, stream its output, and offer to have the agent fix it if it fails.
async function runAndFix(label, cmd, skills) {
  say(ui.dim('  $ ' + cmd));
  const out = await new Promise((resolve) => {
    let buf = '';
    const p = spawn(cmd, { shell: true, cwd: state.cwd });
    const feed = (d) => { process.stdout.write(d); buf += d; };
    p.stdout.on('data', feed); p.stderr.on('data', feed);
    p.on('close', (code) => resolve({ code, buf })); p.on('error', () => resolve({ code: 1, buf: 'failed to start' }));
  });
  if (out.code === 0) return say(ui.green(`\n  ✓ ${label} passed`));
  say(ui.red(`\n  ✗ ${label} failed (exit ${out.code})`));
  if (!(await ask(ui.yellow('  Ask the model to fix it (agent mode)? ') + ui.dim('[y/N] › '))).trim().toLowerCase().startsWith('y')) return;
  const was = state.cfg.agent; state.cfg.agent = true;
  try { await withSkills(skills, () => runTurn(`The command \`${cmd}\` fails. Find the root cause with your tools, fix it, and re-run it to confirm.\n\nOutput (tail):\n\`\`\`\n${out.buf.slice(-6000)}\n\`\`\``, '')); }
  finally { state.cfg.agent = was; }
}
def('lint', 'Run the linter (auto-detected); offer to fix problems: /lint [command]', (a) => {
  const cmd = a || T.lintCommand(state.cwd);
  return cmd ? runAndFix('lint', cmd, ['debug']) : say(ui.red('  no linter detected — use /lint <command>'));
});
def('build', 'Build the project (auto-detected); offer to fix errors: /build [command]', (a) => {
  const cmd = a || T.buildCommand(state.cwd);
  return cmd ? runAndFix('build', cmd, ['debug']) : say(ui.red('  no build command detected — use /build <command>'));
});

def('refactor,rf', 'AI-edit a file with a diff preview and confirmation: /refactor <file> <what to change>', async (a) => {
  const m = /^(\S+)\s+([\s\S]+)$/.exec(a);
  if (!m) return say(ui.red('Usage: /refactor <file> <what to change>'));
  const f = path.resolve(state.cwd, m[1].replace(/^~/, os.homedir()));
  let src; try { src = fs.readFileSync(f, 'utf8'); } catch { return say(ui.red('  cannot read ' + m[1])); }
  if (src.length > 60000) return say(ui.red('  file is too large for /refactor (60k chars max) — use agent mode (/agent on) instead'));
  const sp = new Spinner(brand().rgb); sp.begin();
  let r; try { r = await quiet(`Apply this change to the file below: ${m[2]}\n\nReturn ONLY the complete updated file inside a single fenced code block. Do not shorten, elide or summarize unchanged parts.\n\nFile ${m[1]}:\n\`\`\`\n${src}\n\`\`\``, 'You are a careful senior engineer. Make the requested change and nothing else; keep style and formatting.'); }
  catch (e) { sp.stop(); return say(ui.red('  ' + e.message)); }
  sp.stop();
  if (r.aborted) return say(ui.yellow('  ⎋ stopped'));
  const blocks = [...r.text.matchAll(/```[^\n]*\n([\s\S]*?)```/g)].map((x) => x[1]).sort((x, y) => y.length - x.length);
  if (!blocks.length) return say(ui.red('  the model did not return a complete file in a code block — nothing changed'));
  let next = blocks[0]; if (src.endsWith('\n') && !next.endsWith('\n')) next += '\n';
  if (next === src) return say(ui.dim('  no changes proposed'));
  const tmp = path.join(os.tmpdir(), 'omni-refactor-' + path.basename(f));
  fs.writeFileSync(tmp, next);
  const d = spawnSync('git', ['diff', '--no-index', '--color=always', '--', f, tmp], { encoding: 'utf8' });
  say('\n' + (d.stdout ? d.stdout.replace(/^.*\n(index .*\n)?/, '') : ui.dim(`  (git not available for a diff) new file is ${next.split('\n').length} lines, was ${src.split('\n').length}`)));
  if (next.length < src.length * 0.5) say(ui.yellow('  ⚠ the new version is less than half the size — check that nothing was dropped'));
  try { fs.unlinkSync(tmp); } catch { /* ignore */ }
  if ((await ask(ui.yellow('  Apply this change? ') + ui.dim('[y/N] › '))).trim().toLowerCase().startsWith('y')) { fs.writeFileSync(f, next); say(ui.green('  ✓ written ') + ui.dim(m[1] + '  (undo with: git checkout -- ' + m[1] + ')')); }
  else say(ui.dim('  discarded'));
});

def('standup', 'Draft a standup update from your recent commits: /standup', async () => {
  let who = ''; try { who = git(['config', 'user.name']).trim(); } catch { /* none */ }
  let l = ''; try { l = git(['log', '--since=2 days ago', '--no-merges', '--date=short', '--pretty=format:%h %ad %s', ...(who ? ['--author=' + who] : [])]); } catch { return say(ui.red('  not a git repository')); }
  if (!l.trim()) return say(ui.dim('  no commits in the last 2 days' + (who ? ' by ' + who : '')));
  say();
  await runTurn('Write a short standup update (Yesterday / Today / Blockers) from these recent commits. Plain language, no commit hashes, max 6 bullets. For "Today" suggest the likely next steps and label them as suggestions.\n\n' + l, 'standup');
});
def('readme', 'Let the agent write or improve README.md for this project', async () => {
  const was = state.cfg.agent; state.cfg.agent = true;
  try { await runTurn('Explore this project with your tools (project_summary, tree, read_file, deps), then write or improve README.md: what it is, install, usage with real commands from the code, configuration, development/test commands. Keep existing accurate content. Do not invent features.'); }
  finally { state.cfg.agent = was; }
});
def('log', 'Pretty git history: /log [n]', (a) => {
  try { say(git(['log', '--oneline', '--graph', '--decorate', '--color=always', '-n', String(Math.min(200, Number(a) || 15))])); } catch { say(ui.red('  not a git repository')); }
});
def('tree', 'Directory tree: /tree [depth]', async (a) => say(await toolOut('tree', { depth: Number(a) || 3 })));
def('todos', 'List TODO / FIXME / HACK comments in the project', async () => say(await toolOut('scan_todos')));
def('loc', 'Lines of code by language', async () => say(await toolOut('loc')));
def('secrets', 'Scan the project for leaked keys, tokens and passwords', async () => say(await toolOut('scan_secrets')));
def('deps', 'List project dependencies (npm, pip, go, cargo, composer)', async () => say(await toolOut('deps')));
def('ports', 'Show listening TCP ports: /ports [port]', async (a) => say(await toolOut('ports', { port: a })));

// quick utilities
def('b64', 'Base64 encode / decode: /b64 <text> | /b64 -d <text>', async (a) => say(a.startsWith('-d ') ? await toolOut('encode', { op: 'base64d', text: a.slice(3) }) : await toolOut('encode', { op: 'base64', text: a })));
def('urlenc', 'URL encode / decode: /urlenc <text> | /urlenc -d <text>', async (a) => say(a.startsWith('-d ') ? await toolOut('encode', { op: 'urld', text: a.slice(3) }) : await toolOut('encode', { op: 'url', text: a })));
def('uuid', 'Generate UUID(s): /uuid [count]', async (a) => { const n = Math.min(20, Math.max(1, Number(a) || 1)); for (let i = 0; i < n; i++) say(await toolOut('encode', { op: 'uuid' })); });
def('jwt', 'Decode a JWT (no verification): /jwt <token>', async (a) => say(await toolOut('encode', { op: 'jwt', text: a })));
def('ts', 'Unix <-> ISO time: /ts [unix-or-date]  (no argument = now)', async (a) => say(await toolOut('encode', { op: 'timestamp', text: a })));
def('hash', 'Hash text or a file: /hash [sha256|sha1|sha512|md5] <text | @file>', async (a) => {
  const m = /^(sha256|sha1|sha512|md5)\s+([\s\S]+)$/i.exec(a), algo = m ? m[1] : 'sha256', rest = (m ? m[2] : a).trim();
  if (!rest) return say(ui.red('Usage: /hash [algo] <text | @file>'));
  say(await toolOut('hash', rest.startsWith('@') ? { file: rest.slice(1), algo } : { text: rest, algo }));
});
def('regex,re', 'Test a regex: /regex /pattern/flags some text to search', async (a) => {
  const m = /^\/(.+)\/([a-z]*)\s+([\s\S]+)$/.exec(a);
  if (!m) return say(ui.red('Usage: /regex /pattern/flags text'));
  say(await toolOut('regex_test', { pattern: m[1], flags: m[2] || 'g', text: m[3] }));
});
def('calc', 'Calculator: /calc 2^10 + sqrt(144)', async (a) => say(await toolOut('calc', { expression: a })));

let srv = null;
def('serve', 'Serve the current folder over HTTP: /serve [port] | /serve stop', (a) => {
  if (a === 'stop') { if (srv) { srv.close(); srv = null; return say('  server stopped'); } return say(ui.dim('  not running')); }
  if (srv) return say(ui.yellow('  already running — /serve stop first'));
  const port = Number(a) || 8080, MIME = { html: 'text/html', js: 'text/javascript', css: 'text/css', json: 'application/json', png: 'image/png', jpg: 'image/jpeg', svg: 'image/svg+xml', txt: 'text/plain', md: 'text/plain', wasm: 'application/wasm' };
  srv = require('http').createServer((req, res) => {
    let f = path.resolve(state.cwd, '.' + path.sep + decodeURIComponent(req.url.split('?')[0]).replace(/^\/+/, ''));
    if (f !== state.cwd && !f.startsWith(state.cwd + path.sep)) { res.statusCode = 403; return res.end('forbidden'); }
    try {
      if (fs.statSync(f).isDirectory()) {
        const ix = path.join(f, 'index.html');
        if (fs.existsSync(ix)) f = ix;
        else { res.setHeader('content-type', 'text/html; charset=utf-8'); return res.end('<pre>' + fs.readdirSync(f).map((n) => `<a href="${req.url.replace(/\/?$/, '/')}${encodeURIComponent(n)}">${n.replace(/</g, '&lt;')}</a>`).join('\n') + '</pre>'); }
      }
      res.setHeader('content-type', MIME[path.extname(f).slice(1).toLowerCase()] || 'application/octet-stream'); fs.createReadStream(f).pipe(res);
    } catch { res.statusCode = 404; res.end('not found'); }
  });
  srv.on('error', (e) => { say(ui.red('  ' + e.message)); srv = null; });
  srv.listen(port, () => say(`  serving ${state.cwd}\n  ${accent('http://localhost:' + port)}  ${ui.dim('(/serve stop to end)')}`));
});

// user-defined slash commands, saved in ~/.omni/config.json
def('macro', 'Your own slash commands: /macro add <name> <prompt, use {{args}}> | list | rm <name>', (a) => {
  state.cfg.macros = state.cfg.macros || {};
  const m = /^(\w+)\s*(\S*)\s*([\s\S]*)$/.exec(a) || [];
  if (m[1] === 'add') {
    const name = m[2].toLowerCase(), prompt = m[3].trim();
    if (!name || !prompt) return say(ui.red('Usage: /macro add <name> <prompt>   e.g. /macro add tldr Summarize in 3 bullets: {{args}}'));
    if (CMDS[name] && !state.cfg.macros[name]) return say(ui.red(`  /${name} is a built-in command — pick another name`));
    state.cfg.macros[name] = prompt; save(); return say(`  saved ${accent('/' + name)}`);
  }
  if (m[1] === 'rm' || m[1] === 'remove') { const n = m[2].toLowerCase(); if (!state.cfg.macros[n]) return say(ui.red('  no such macro')); delete state.cfg.macros[n]; save(); return say('  removed /' + n); }
  const es = Object.entries(state.cfg.macros);
  say(es.length ? es.map(([k, v]) => `  ${accent(('/' + k).padEnd(14))} ${ui.dim(v.replace(/\n/g, ' ').slice(0, 90))}`).join('\n') : ui.dim('  no macros yet — /macro add tldr Summarize in 3 bullets: {{args}}'));
});

def('exit,quit,q', 'Quit', () => { say(ui.dim('bye')); process.exit(0); });

async function handle(line) {
  if (line.startsWith('!')) {
    await new Promise((r) => { const p = spawn(line.slice(1), { shell: true, cwd: state.cwd, stdio: 'inherit' }); p.on('close', r); p.on('error', r); });
    return;
  }
  if (line.startsWith('/')) {
    const m = /^\/(\S*)\s*([\s\S]*)$/.exec(line), name = m[1].toLowerCase(), cmd = CMDS[name];
    if (!cmd) {
      const mac = (state.cfg.macros || {})[name], args = m[2].trim();
      if (mac) { say(); return runTurn(mac.includes('{{args}}') ? mac.replace(/\{\{args\}\}/g, () => args) : (args ? mac + '\n\n' + args : mac)); }
      const guess = Object.keys(CMDS).filter((k) => k.startsWith(name)).slice(0, 4);
      return say(ui.red(`Unknown command /${name}`) + (guess.length ? ui.dim('  did you mean ' + guess.map((g) => '/' + g).join(', ') + '?') : ui.dim('  try /help')));
    }
    return cmd.fn(m[2].trim());
  }
  if (/^(exit|quit)$/i.test(line)) return CMDS.exit.fn();
  say();
  await runTurn(line);
}

function completer(line) {
  if (!line.startsWith('/')) return [[], line];
  const parts = line.split(' ');
  if (parts.length === 1) { const h = [...Object.keys(CMDS), ...Object.keys(state.cfg.macros || {})].map((c) => '/' + c).filter((c) => c.startsWith(line)); return [h, line]; }
  const MODEL_WORDS = Object.values(P.MODEL_ALIASES).flatMap((o) => Object.keys(o));
  const pv = [...Object.keys(P.PROVIDERS), ...Object.keys(P.MODEL_ALIASES.claude).map((k) => 'claude:' + k)];
  const sets = { '/provider': pv, '/p': pv, '/model': MODEL_WORDS, '/m': MODEL_WORDS, '/plan': ['on', 'off'], '/info': ['-l'], '/i': ['-l'], '/review': ['staged', 'branch'], '/effort': EFFORTS, '/e': EFFORTS, '/skill': S.names(), '/s': S.names(), '/skills': [...S.cats(), 'auto', 'max'], '/macro': ['add', 'list', 'rm'], '/serve': ['stop'], '/hash': ['sha256', 'sha1', 'sha512', 'md5'] };
  const set = sets[parts[0]], last = parts[parts.length - 1];
  return set ? [set.filter((x) => x.startsWith(last)), last] : [[], line];
}

// ---------- entry ----------
function parseArgs(argv) {
  const a = { skills: [], rest: [] };
  for (let i = 0; i < argv.length; i++) {
    const x = argv[i], nx = () => argv[++i];
    if (x === '-h' || x === '--help') a.help = true;
    else if (x === '-v' || x === '--version') a.version = true;
    else if (x === '-p' || x === '--print') a.print = true;
    else if (x === '-P' || x === '--provider') a.provider = nx();
    else if (x === '-m' || x === '--model') a.model = nx();
    else if (x === '-e' || x === '--effort') a.effort = nx();
    else if (x === '-a' || x === '--agent') a.agent = true;
    else if (x === '-s' || x === '--skill') a.skills.push(nx());
    else if (x === '-y' || x === '--yes') a.yes = true;
    else if (x === '--no-think') a.noThink = true;
    else if (x === '--plan') a.plan = true;
    else if (x === '--no-skills') a.noSkills = true;
    else a.rest.push(x);
  }
  return a;
}

const HELP = `Omni CLI v${VERSION} — chat with Ollama, Claude, Gemini, OpenAI and xAI from your terminal

Usage:
  omni [options] [prompt]        interactive chat (optional first prompt)
  omni -p "question" [options]   one-shot, prints the answer and exits (stdin is appended)

Options:
  -P, --provider <name>   ollama | claude | gemini | openai | xai   (also provider:model, e.g. claude:opus)
  -m, --model <name>      model for the chosen provider (aliases: sonnet, opus, haiku; or any part of a model name)
  -e, --effort <level>    low | medium | high | max
  -a, --agent             enable agent mode (tools)
  -s, --skill <name>      activate a skill (repeatable)
  -y, --yes               auto-approve tool actions
      --no-think          hide the thinking stream
      --plan              plan mode (read-only, no changes)
      --no-skills         turn off automatic skill routing
  -v, --version  -h, --help

Inside the app type /help. API keys: /key <provider> <key> or env vars
ANTHROPIC_API_KEY, GEMINI_API_KEY, OPENAI_API_KEY, XAI_API_KEY, OLLAMA_HOST.`;

// Reads piped stdin. With a prompt already given, don't wait forever for input that never comes.
function readStdin(idleMs) {
  return new Promise((resolve) => {
    let d = '', got = false, timer = null;
    process.stdin.setEncoding('utf8');
    const done = () => { clearTimeout(timer); process.stdin.pause(); resolve(d); };
    if (idleMs) timer = setTimeout(() => { if (!got) done(); }, idleMs);
    process.stdin.on('data', (c) => { got = true; d += c; });
    process.stdin.on('end', done);
    process.stdin.on('error', done);
  });
}

async function main(argv) {
  const a = parseArgs(argv);
  if (a.help) return say(HELP);
  if (a.version) return say(VERSION);
  if (a.rest[0] === 'info') {   // omni info [-l]  — works from the shell using the last saved response
    let l = null; try { l = JSON.parse(fs.readFileSync(path.join(cfgMod.DIR, 'last.json'), 'utf8')); } catch { /* none */ }
    const wantLast = a.rest.includes('-l') || a.rest.includes('--last') || a.last;
    if (!wantLast) say(`  omni-cli v${VERSION} · config ${cfgMod.FILE}\n  provider ${state.cfg.provider} / ${state.cfg.models[state.cfg.provider]} · effort ${state.cfg.effort}\n  use: omni info -l   (details of the last response)\n`);
    return say(l ? infoLast(l) : '  no response saved yet — ask something first (omni -p "hi")');
  }
  const c = state.cfg;
  if (a.provider) {
    const [pn, pm] = a.provider.split(':'), p = P.ALIASES[pn] || pn;
    if (!P.PROVIDERS[p]) { say(ui.red('Unknown provider ' + a.provider)); process.exit(1); }
    c.provider = p; if (pm && !a.model) a.model = pm;
  }
  if (c.provider === 'ollama' && !a.model) await ensureOllamaModel();
  if (a.model) c.models[c.provider] = await P.resolveModel(c, c.provider, a.model);
  if (a.plan) c.plan = true;
  if (a.noSkills) c.skillsAuto = false;
  if (a.effort && EFFORTS.includes(a.effort)) c.effort = a.effort;
  if (a.agent) c.agent = true;
  if (a.yes) c.autoApprove = true;
  if (a.noThink) c.thinkingView = false;
  for (const n of a.skills) { const s = S.find(n); if (s) state.skills.push(s.name); else say(ui.red('Unknown skill ' + n)); }

  const piped = !process.stdin.isTTY;
  if (a.print || piped) {
    let prompt = a.rest.join(' ');
    if (piped) { const d = await readStdin(prompt ? 400 : 0); prompt = (prompt && d ? prompt + '\n\n' : prompt) + d; }
    if (!prompt.trim()) { say(ui.red('No prompt given. Use: omni -p "your question"')); process.exit(1); }
    c.thinkingView = false;
    try { await runTurn(prompt.trim()); } catch (e) { say(ui.red('Error: ' + e.message)); process.exit(1); }
    return;
  }

  const rl = readline.createInterface({ input: process.stdin, output: process.stdout, completer, historySize: 500 });
  state.rl = rl;
  const hf = path.join(cfgMod.DIR, 'history');
  try { rl.history = fs.readFileSync(hf, 'utf8').split('\n').filter(Boolean).slice(-500).reverse(); } catch { /* none yet */ }
  rl.on('close', () => { say(''); process.exit(0); });
  let armed = false;
  rl.on('SIGINT', () => {
    if (state.busy) { if (state.abort) state.abort.abort(); return; }
    if (armed) return rl.close();
    armed = true; say(ui.dim('\n(press Ctrl+C again to exit)')); setTimeout(() => { armed = false; }, 2000);
  });

  await showLogo(true);
  if (c.provider !== 'ollama' && !cfgMod.getKey(c, c.provider)) say(ui.yellow(`\n  No API key for ${brand().label}. Run:  /key ${c.provider} <your-key>`));
  let first = a.rest.join(' ') || null;
  for (;;) {
    let line;
    if (first) { line = first; first = null; say(`\n${accent('❯')} ${line}`); }
    else {
      statusRule(); line = await ask(accent('❯') + ' ');
      while (line.endsWith('\\')) line = line.slice(0, -1) + '\n' + await ask(ui.dim('… '));
    }
    line = line.trim();
    if (!line) continue;
    if (/^\/key\b/i.test(line)) { try { rl.history.shift(); } catch { /* ignore */ } }
    else { try { fs.appendFileSync(hf, line.replace(/\n/g, ' ') + '\n'); } catch { /* ignore */ } }
    try { await handle(line); } catch (e) { say(ui.red('\nError: ' + e.message)); }
  }
}

module.exports = { main };
